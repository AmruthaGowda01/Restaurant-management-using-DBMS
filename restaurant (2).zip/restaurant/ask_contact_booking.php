<html>
<title>Check Contact</title>
<?php
function check_booking_contact($contact)
{
    // Create a new MySQLi connection
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');

    // Check for connection errors
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }

    // Check if the contact is empty
    if (empty($contact)) {
        echo "<script type=\"text/javascript\">" . "\n";
        echo "alert(\"No Contact Added!!!\");" . "\n";
        echo "</script>" . "\n";
        echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=user.html\">";
        return;
    }

    // Prepare the query to check if the contact exists
    $query = "SELECT * FROM CUSTOMER WHERE Contact = ?";
    if ($stmt = $dbc->prepare($query)) {
        // Bind the contact parameter
        $stmt->bind_param("s", $contact);

        // Execute the query
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if the contact exists
        if ($result->num_rows > 0) {
            $cust_id = $result->fetch_assoc()['Customer_Id'];
            // Prepare the form to check customer details
            echo "<form id=\"form1\" name=\"form1\" action=\"customer_booking_details1.php\" method=\"post\">";
            echo "<input type=\"hidden\" name=\"cust_id\" value=\"$cust_id\">";
            echo "<input type=\"submit\" name=\"submitbutton\" value=\"Check\">";
            echo "</form>";
            echo "<script type=\"text/javascript\">" . "\n";
            echo "document.getElementById(\"form1\").submit();";
            echo "</script>" . "\n";
        } else {
            // If customer doesn't exist, proceed with a new booking
            echo "<form id=\"form1\" name=\"form1\" action=\"customer_booking_details.php\" method=\"post\">";
            echo "<input type=\"hidden\" name=\"contact\" value=\"$contact\">";
            echo "<input type=\"submit\" name=\"submitbutton\" value=\"Check\">";
            echo "</form>";
            echo "<script type=\"text/javascript\">" . "\n";
            echo "document.getElementById(\"form1\").submit();";
            echo "</script>" . "\n";
        }

        // Close the prepared statement
        $stmt->close();
    } else {
        echo "<script type=\"text/javascript\">" . "\n";
        echo "alert(\"Error preparing the query: " . $dbc->error . "\");" . "\n";
        echo "</script>" . "\n";
    }

    // Close the database connection
    $dbc->close();
}

check_booking_contact($_POST["contact"]);
?>
</body>
</html>
