<!DOCTYPE html>
<html>
<head>
    <title>Update Employee</title>
    <style type="text/css">
        label {
            float: left;
            width: 700px;
            font-weight: bold;
        }
        input, textarea {
            width: 200px;
            margin-bottom: 9px;
        }
        br {
            clear: left;
        }
    </style>
</head>
<body background="1.png">
    <h1 style="text-align:center"> Update Employee </h1>
    <?php
        // Function to display employee data from a specific table
        function print_employee($employee_type) {
            // Connect to the database
            $conn = mysqli_connect('localhost', 'root', '', 'restaurant');
            if (!$conn) {
                die('NOT CONNECTED: ' . mysqli_connect_error());
            }

            // Query to fetch all employees from the specified table
            $query = "SELECT * FROM $employee_type";
            $emp = mysqli_query($conn, $query);
            $num_items = mysqli_num_rows($emp);
            $num_fields = mysqli_num_fields($emp);

            if (!$num_items) {
                echo "<script type=\"text/javascript\">" . "\n";
                echo "alert(\"No $employee_type Added!!!\");" . "\n";
                echo "</script>" . "\n";
                return;
            }

            echo "<table border=\"2\" style=\"text-align:center;\" align=\"center\" width=\"1200\">" . "\n";
            echo "<tr>" . "\n";

            // Print column headers (field names)
            for ($i = 0; $i < $num_fields; $i++) {
                echo "<td>" . "\n";
                echo mysqli_fetch_field_direct($emp, $i)->name;
                echo "</td>" . "\n";
            }

            echo "<td>" . "\n";
            echo "Select To Update" . "\n";
            echo "</td>" . "\n";
            echo "</tr>" . "\n";

            // Print employee data
            for ($i = 0; $i < $num_items; $i++) {
                $row = mysqli_fetch_row($emp);
                echo "<tr>" . "\n";
                echo "<label for=\"$employee_type\">";
                for ($j = 0; $j < $num_fields; $j++) {
                    echo "<td>" . "\n";
                    echo $row[$j] . " " . "\n";
                    echo "</td>" . "\n";
                }
                $id = $row[0] . "," . $employee_type;
                echo "</label>" . "\n";
                echo "<td>" . "\n";
                echo "<input type=\"radio\" name=\"employee\" value=\"$id\"><br/>" . "\n";
                echo "</td>" . "\n";
                echo "</tr>" . "\n";
            }
            echo "</table>" . "\n";
            echo "<br/>" . "\n";
            return $num_items;
        }

        // Function to display all employees and provide an option to update
        function print_users() {
            // Connect to the database
            $conn = mysqli_connect('localhost', 'root', '', 'restaurant');
            if (!$conn) {
                die('NOT CONNECTED: ' . mysqli_connect_error());
            }

            $num_emp = 0;
            echo "<form action=\"update_employee.php\" method=\"post\" align=\"center\">" . "\n";

            // Display sections for different employee types
            echo "<h1 style=\"text-align:center\"> Managers </h1>" . "\n";
            $num_emp += print_employee("MANAGER");

            echo "<h1 style=\"text-align:center\"> Cooks </h1>" . "\n";
            $num_emp += print_employee("COOK");

            echo "<h1 style=\"text-align:center\"> Cashiers </h1>" . "\n";
            $num_emp += print_employee("CASHIER");

            echo "<h1 style=\"text-align:center\"> Waiters </h1>" . "\n";
            $num_emp += print_employee("WAITER");

            echo "<h1 style=\"text-align:center\"> Delivery Boys </h1>" . "\n";
            $num_emp += print_employee("DELIVERY_BOY");

            // If no employees found, show an alert
            if (!$num_emp) {
                echo "<script type=\"text/javascript\">" . "\n";
                echo "alert(\"No Employees Added!!!\");" . "\n";
                echo "</script>" . "\n";
                echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=admin.html\">";
                return;
            }

            // Submit button to update selected employee
            echo "<input type=\"submit\" value=\"Update Selected Employee\">" . "\n";
        }

        // Call the function to print the users
        print_users();
    ?>
</body>
</html>
