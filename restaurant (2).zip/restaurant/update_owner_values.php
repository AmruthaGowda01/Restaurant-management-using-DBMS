<html>
<title>Update User</title>
<?php
function update_owner_values($firstname, $lastname, $contact, $rest_name)
{	
    // Create a new MySQLi connection
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');

    // Check for connection errors
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }

    // Prepare the update query
    $query = "UPDATE `OWNER` SET `Fname` = ?, `Lname` = ?, `Contact` = ? WHERE `Rest_Name` = ?";

    // Initialize prepared statement
    if ($stmt = $dbc->prepare($query)) {

        // Bind parameters to the prepared statement
        $stmt->bind_param("ssss", $firstname, $lastname, $contact, $rest_name);

        // Execute the statement
        if ($stmt->execute()) {
            echo "<script type=\"text/javascript\"> alert(\"Owner Updated !!!\"); </script>";
        } else {
            echo "<script type=\"text/javascript\"> alert(\"Failed to update owner.\"); </script>";
        }

        // Close the statement
        $stmt->close();
    } else {
        echo "<script type=\"text/javascript\"> alert(\"Query preparation failed.\"); </script>";
    }

    // Close the database connection
    $dbc->close();
}

// Call the function with POST data
update_owner_values(
    $_POST["Fname"],
    $_POST["Lname"],
    $_POST["Contact"],
    $_POST["Rest_Name"]
);
?>
<script type="text/javascript">
    function done() {
        alert("Owner Updated !!!");
    }
</script>
<body onload="done()" background="1.png">
<meta HTTP-EQUIV="REFRESH" content="0; url=admin.html">
</body>
</html>
