<html>
<title>Bill</title>
<h1 style="text-align:center">Bill</h1><br/>
<style type="text/css">
label {
    float: left;
    width: 120px;
    font-weight: bold;
}
input, textarea {
    width: 200px;
    margin-bottom: 9px;
}
br {
    clear: left;
}
</style>
<body background="1.png">
<?php
function print_bill($menu_id, $cust_id, $fname, $lname, $contact, $email_id, $quantity, $address)
{
    // Create MySQLi connection
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');
    
    // Check for connection errors
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }

    // Query to fetch customer details
    $query = "SELECT * FROM CUSTOMER WHERE Customer_Id = ?";
    if ($stmt = $dbc->prepare($query)) {
        $stmt->bind_param("i", $cust_id);
        $stmt->execute();
        $res = $stmt->get_result();
        $num_fields = $res->field_count;

        echo "<table border=\"2\" style=\"text-align:center;\" align=\"center\" width=\"500\">";
        while ($row = $res->fetch_assoc()) {
            foreach ($row as $field => $value) {
                if ($field != 'Customer_Id') { // Avoid showing ID here
                    echo "<tr><td>$field</td><td>$value</td></tr>";
                }
            }
        }
        echo "</table><br/>";
    }

    // Query to fetch menu items
    $query = "SELECT * FROM MENU";
    $menu = $dbc->query($query);
    $num_fields = $menu->field_count;

    echo "<table border=\"2\" style=\"text-align:center;\" align=\"center\" width=\"500\">";
    echo "<tr><td>S.No</td><td>Name</td><td>Price ($)</td><td>Quantity</td><td>Total ($)</td></tr>";

    $total_amount = 0;
    $num_items = count($menu_id);
    for ($i = 0; $i < $num_items; $i++) {
        $query = "SELECT Name, Price FROM MENU WHERE Menu_Id = ?";
        if ($stmt = $dbc->prepare($query)) {
            $stmt->bind_param("i", $menu_id[$i]);
            $stmt->execute();
            $menu_item = $stmt->get_result()->fetch_assoc();
            $name = $menu_item['Name'];
            $price = $menu_item['Price'];
            $qty = $quantity[$i];
            $total = $price * $qty;
            $total_amount += $total;

            echo "<tr><td>" . ($i + 1) . "</td><td>$name</td><td>$price</td><td>$qty</td><td>$total</td></tr>";
        }
    }
    echo "</table><br/>";

    // Display total amount
    echo "<table border=\"2\" style=\"text-align:center;\" align=\"center\" width=\"200\">";
    echo "<tr><td>Total Amount</td><td>$total_amount</td></tr>";
    echo "</table><br/>";

    // Insert bill information into BILL table
    $query = "INSERT INTO BILL (Customer_Fname, Customer_Lname, Customer_Id, Total_Amount) VALUES (?, ?, ?, ?)";
    if ($stmt = $dbc->prepare($query)) {
        $stmt->bind_param("ssii", $fname, $lname, $cust_id, $total_amount);
        $stmt->execute();
        $order_id = $stmt->insert_id; // Get the last inserted ID
    }

    // Insert menu items into MENU_BILL table
    for ($i = 0; $i < $num_items; $i++) {
        $query = "SELECT Name, Price FROM MENU WHERE Menu_Id = ?";
        if ($stmt = $dbc->prepare($query)) {
            $stmt->bind_param("i", $menu_id[$i]);
            $stmt->execute();
            $menu_item = $stmt->get_result()->fetch_assoc();
            $name = $menu_item['Name'];
            $price = $menu_item['Price'];
            $qty = $quantity[$i];

            // Insert each menu item into the MENU_BILL table
            $query = "INSERT INTO MENU_BILL (Order_Id, Name, Quantity, Price) VALUES (?, ?, ?, ?)";
            if ($stmt = $dbc->prepare($query)) {
                $stmt->bind_param("isid", $order_id, $name, $qty, $price);
                $stmt->execute();
            }
        }
    }

    // Insert home delivery information into HOME_DELIVERY table
    $query = "INSERT INTO HOME_DELIVERY (Address, Contact, Cust_Id, Order_Id) VALUES (?, ?, ?, ?)";
    if ($stmt = $dbc->prepare($query)) {
        $stmt->bind_param("ssii", $address, $contact, $cust_id, $order_id);
        $stmt->execute();
    }

    // Close the connection
    $dbc->close();
}

// Call the function with POST data
print_bill(
    $_POST["menu"],
    $_POST["Customer_Id"],
    $_POST["Fname"],
    $_POST["Lname"],
    $_POST["Contact"],
    $_POST["Email_Id"],
    $_POST["quantity"],
    $_POST["address"]
);
?>
</body>
</html>
