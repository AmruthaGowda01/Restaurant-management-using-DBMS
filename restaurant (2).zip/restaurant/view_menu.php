<html>
<title>Menu</title>
<h1 style="text-align:center">Menu</h1>
<style type="text/css">
div.div1 {
    text-align:center;
    font-weight: bold;
}
</style>

<?php
// Function to print menu items from the database
function print_menu()
{
    // Create a connection to the MySQL database using mysqli
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }

    // Query to select all items from the MENU table
    $query = "SELECT * FROM MENU";
    $result = $dbc->query($query);

    // Check if there are any items in the menu
    if ($result->num_rows == 0) {
        echo "<script type=\"text/javascript\">\n";
        echo "alert(\"No Items In Menu !!!\");\n";
        echo "</script>\n";
        echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=admin.html\">\n";
        return;
    }

    // Output the table header with column names
    echo "<tr>\n";
    $fields = $result->fetch_fields();
    foreach ($fields as $field) {
        echo "<td>\n";
        echo $field->name;
        echo "</td>\n";
    }
    echo "</tr>\n";

    // Output the table rows with menu item data
    while ($row = $result->fetch_assoc()) {
        echo "<tr>\n";
        foreach ($row as $value) {
            echo "<td>\n";
            echo $value . " \n";
            echo "</td>\n";
        }
        echo "</tr>\n";
    }

    // Free the result to release memory
    $result->free();
}
?>

<body background="1.png">
<table border="2" style="text-align:center;" align="center" width="700">
<?php
// Call the function to display the menu
print_menu();
?>
</table>
</body>
</html>
