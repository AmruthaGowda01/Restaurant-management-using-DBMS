<html>
<title> Add Supplier </title>
<?php
function add_supplier($fname, $lname, $address, $contact, $details)
{
    // Establish a connection to the MySQL database using mysqli
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');
    
    // Check if the connection is successful
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }
    
    // Prepare the INSERT query to avoid SQL injection
    $query = "INSERT INTO `SUPPLIER` (`Fname`, `Lname`, `Address`, `Contact`, `Details`) VALUES (?, ?, ?, ?, ?)";
    
    // Prepare the statement
    $stmt = $dbc->prepare($query);
    
    // Bind the parameters to the statement
    $stmt->bind_param("sssss", $fname, $lname, $address, $contact, $details);
    
    // Execute the statement
    $stmt->execute();
    
    // Close the statement and connection
    $stmt->close();
    $dbc->close();
}

add_supplier(
    $_POST["Fname"],
    $_POST["Lname"],
    $_POST["Address"],
    $_POST["Contact"],
    $_POST["Details"]
);
?>
<script type="text/javascript">
    function done() {
        alert("New Supplier Added!!!");
    }
</script>
<body onload="done()" background="1.png">
    <meta HTTP-EQUIV="REFRESH" content="0; url=admin.html">
</body>
</html>
