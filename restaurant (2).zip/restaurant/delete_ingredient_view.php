<html>
<title>Delete Ingredients</title>
<h1 style="text-align:center">Delete Ingredients</h1>
<style type="text/css">
div.div1 {
    text-align: center;
    font-weight: bold;
}
</style>
<style type="text/css">
label {
    float: left;
    width: 120px;
    font-weight: bold;
}
input, textarea {
    width: 200px;
    margin-bottom: 9px;
}
br {
    clear: left;
}
</style>

<?php
function print_ingredients()
{
    // Create a connection to the MySQL database using MySQLi
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');
    
    // Check for connection errors
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }
    
    // Query to select all ingredients from the database
    $query = "SELECT * FROM INGREDIENT";
    $result = $dbc->query($query);
    
    // Check if there are any ingredients in the database
    if ($result->num_rows == 0) {
        echo "<script type=\"text/javascript\">" . "\n";
        echo "alert(\"No Ingredients !!!\");" . "\n";
        echo "</script>" . "\n";
        echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=admin.html\">" . "\n";
        return;
    }
    
    // Start form to display the ingredients
    echo "<form action=\"delete_ingredient.php\" method=\"post\" align=\"center\">" . "\n";
    echo "<table border=\"4\" style=\"text-align:center;\" align=\"center\" width=\"900\">" . "\n";
    echo "<tr>" . "\n";
    
    // Output column headers (field names)
    $field_count = $result->field_count;
    while ($field_info = $result->fetch_field()) {
        echo "<td>" . htmlspecialchars($field_info->name) . "</td>" . "\n";
    }
    
    echo "<td>" . "\n";
    echo "Select To Delete" . "\n";
    echo "</td>" . "\n";
    echo "</tr>" . "\n";
    
    // Output rows of ingredients
    while ($row = $result->fetch_assoc()) {
        echo "<tr>" . "\n";
        foreach ($row as $column_value) {
            echo "<td>" . htmlspecialchars($column_value) . "</td>" . "\n";
        }
        echo "<td>" . "\n";
        echo "<input type=\"checkbox\" name=\"ingredient[]\" value=\"" . htmlspecialchars($row['Ingredient_Id']) . "\"><br/>" . "\n";
        echo "</td>" . "\n";
        echo "</tr>" . "\n";
    }
    
    echo "</table>" . "\n";
    echo "<br/>";
    echo "<input type=\"submit\" value=\"Delete Selected Items\">" . "\n";
    
    // Close the result set
    $result->free();
    
    // Close the database connection
    $dbc->close();
}
?>

<body background="1.png">
<?php
print_ingredients();
?>
</body>
</html>
