<!DOCTYPE html>
<html>
<head>
    <title>ADD EMPLOYEE</title>
</head>
<body background="1.png">
    <?php
        function add_employee($firstname, $lastname, $contact, $salary, $address, $sex, $bdate, $joindate, $type)
        {
            // Database connection using mysqli
            $conn = mysqli_connect('localhost', 'root', '', 'restaurant');
            if (!$conn) {
                die('NOT CONNECTED: ' . mysqli_connect_error());
            }

            // Prepare the SQL insert query using placeholders
            $query = "INSERT INTO `$type` (Fname, Lname, Contact, Address, Salary, Sex, Bdate, Join_Date) 
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $query);
            if (!$stmt) {
                die('Prepared statement failed: ' . mysqli_error($conn));
            }

            // Bind the parameters to the placeholders
            mysqli_stmt_bind_param($stmt, 'ssssssss', $firstname, $lastname, $contact, $address, $salary, $sex, $bdate, $joindate);

            // Execute the statement
            $result = mysqli_stmt_execute($stmt);
            if (!$result) {
                die('Query execution failed: ' . mysqli_stmt_error($stmt));
            }

            // Close the prepared statement and the connection
            mysqli_stmt_close($stmt);
            mysqli_close($conn);
        }

        // Call the function with POST data from the form
        add_employee(
            $_POST["firstname"],
            $_POST["lastname"],
            $_POST["contact"],
            $_POST["salary"],
            $_POST["address"],
            $_POST["sex"],
            $_POST["bdate"],
            $_POST["joindate"],
            $_POST["type"]
        );
    ?>

    <script type="text/javascript">
        function done() {
            alert("EMPLOYEE ADDED!!!");
        }
    </script>

    <body onload="done()">
        <meta HTTP-EQUIV="REFRESH" content="0; url=admin.html">
    </body>
</html>
