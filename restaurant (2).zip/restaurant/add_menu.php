<html>
<title>ADD MENU ITEMS</title>
<?php
// Function to add new menu items
function add_menu_items($food_name, $food_price, $food_type, $food_category)
{
    // Create a connection to the MySQL database using mysqli
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }

    // Escape user inputs to prevent SQL injection
    $food_name = $dbc->real_escape_string($food_name);
    $food_price = $dbc->real_escape_string($food_price);
    $food_type = $dbc->real_escape_string($food_type);
    $food_category = $dbc->real_escape_string($food_category);

    // Query to insert the new item into the MENU table
    $query = "INSERT INTO `MENU`(`Name`, `Price`, `Type`, `Category`) 
              VALUES ('$food_name', '$food_price', '$food_type', '$food_category')";

    // Execute the query
    if ($dbc->query($query) === TRUE) {
        return true;
    } else {
        return false;
    }
}

// Call the function to add menu items
if (add_menu_items($_POST["food_name"], $_POST["food_price"], $_POST["food_type"], $_POST["food_category"])) {
    echo "<script type=\"text/javascript\">
        function done() {
            alert('New Item Added!!!');
        }
        </script>";
} else {
    echo "<script type=\"text/javascript\">
        function done() {
            alert('Error Adding Item!');
        }
        </script>";
}
?>
<body onload="done()" background="1.png">
<meta HTTP-EQUIV="REFRESH" content="2; url=admin.html">
</body>
</html>
