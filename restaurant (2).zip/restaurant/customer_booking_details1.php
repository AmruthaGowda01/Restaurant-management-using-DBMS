<html>
<head>
<title>Booking</title>
</head>
<body>
<h1 style="text-align:center">Booking</h1><br/><br/>
<script type="text/javascript" src="check_form_validate.js"></script>
<body background="1.png">
<form name="form1" action="add_customer_booking.php" method="post" onsubmit="return checkscript()">

<table border=2 style="text-align:center;" align="center" width="500">
<?php
// Create a new MySQLi connection
$dbc = new mysqli('localhost', 'root', '', 'restaurant');

// Check for connection errors
if ($dbc->connect_error) {
    die('Connection failed: ' . $dbc->connect_error);
}

// Get the customer ID from the POST request
$c = $_POST["cust_id"];
//echo $c;

// Use prepared statement to select customer details
$query = "SELECT * FROM CUSTOMER WHERE Customer_Id = ?";
if ($stmt = $dbc->prepare($query)) {
    $stmt->bind_param("i", $c);  // Bind the customer ID as an integer
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($customer_id, $fname, $lname, $contact, $email_id);
    $stmt->fetch();
    // Display the customer details in the form
    echo "<tr><label for='firstname'><td>First name: </td></label><td><input type='text' name='firstname' value=\"$fname\" ></td></tr>";
    echo "<tr><label for='lastname'><td>Last name: </td></label><td><input type='text' name='lastname' value='$lname' readonly='readonly'></td></tr>";
    echo "<tr><label for='contact'><td>Contact: </td></label><td><input type='text' name='contact' value='$contact' readonly='readonly'></td></tr>";
    echo "<tr><label for='email_id'><td>Email Id: </td></label><td><input type='text' name='email_id' value='$email_id' readonly='readonly'></td></tr>";
    $stmt->close();
}

// Get available tables for booking
$query = "SELECT Table_Number FROM TABLES";
$table = $dbc->query($query);
echo "<tr><label for='table_number'><td>Table Number: </td></label><td><select name='table_number' style='width: 200px;'>";
while ($row = $table->fetch_assoc()) {
    $val = $row['Table_Number'];
    echo "<option value='$val'>$val</option>";
}
echo "</select></td></tr>";

// Close the database connection
$dbc->close();
?>
<tr><label for="date"><td>Date: </td></label><td><input type="text" name="date" required></td></tr>
<tr><label for="time"><td>Time: </td></label><td><input type="text" name="time" required></td></tr>
</table><br/>
<table border=0 style="text-align:center;" align="center"><tr><td><input type="submit" name="submitbutton" value="Book"></td></tr></table>

</form>

<style type="text/css">
label {
    float: left;
    width: 120px;
    font-weight: bold;
}
input, textarea {
    width: 200px;
    margin-bottom: 9px;
}
br {
    clear: left;
}
</style>
</body>
</html>
