<html>
<title> Delete Employees </title>
<style type="text/css">
label{
float: left;
width: 700px;
       font-weight: bold;
}
input, textarea{
width: 200px;
       margin-bottom: 9px;
}
br{
clear: left;
}
</style>

<h1 style="text-align:center"> Delete Employees </h1>

<?php

// Function to print employee data for each type
function print_employee($employee_type)
{
    // Create a connection to the MySQL database
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }

    // Query to select all employees for the given type
    $query = "SELECT * FROM $employee_type";
    $result = $dbc->query($query);

    if ($result->num_rows == 0) {
        echo "<script type=\"text/javascript\">\n";
        echo "alert(\"No $employee_type Added!!!\");\n";
        echo "</script>\n";
        return;
    }

    // Display the employee data in a table
    echo "<table border=\"2\" style=\"text-align:center;\" align=\"center\" width=\"1200\">\n";
    echo "<tr>\n";
    
    // Display column names
    $fields = $result->fetch_fields();
    foreach ($fields as $field) {
        echo "<td>\n";
        echo $field->name;
        echo "</td>\n";
    }
    
    echo "<td>\n";
    echo "Select To Delete\n";
    echo "</td>\n";
    echo "</tr>\n";

    // Display rows of data
    while ($row = $result->fetch_assoc()) {
        echo "<tr>\n";
        echo "<label for=\"$employee_type\">";
        foreach ($row as $column => $value) {
            echo "<td>\n";
            echo $value . " \n";
            echo "</td>\n";
        }
        echo "</label>\n";
        echo "<td>\n";
		//$aa=ucwords(str_replace("_", " ", $employee_type)); 
        $id = $row[$employee_type.'_Id']; // Assuming the first column is the ID
		//echo $aa.'_Id';
        $type = $employee_type . "[]";
        echo "<input type=\"checkbox\" name=\"$type\" value=\"$id\"><br/>\n";
        echo "</td>\n";
        echo "</tr>\n";
    }

    echo "</table>\n";
    echo "<br/>\n";
    return;
}

// Function to print all employees
function print_users()
{
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }

    $num_emp = 0;
    echo "<form action=\"delete_employees.php\" method=\"post\" align=\"center\">\n";
    echo "<h1 style=\"text-align:center\"> Managers </h1>\n";
    $num_emp .= print_employee("Manager");
    echo "<h1 style=\"text-align:center\"> Cooks </h1>\n";
    $num_emp .= print_employee("Cook");
    echo "<h1 style=\"text-align:center\"> Cashiers </h1>\n";
    $num_emp .= print_employee("Cashier");
    echo "<h1 style=\"text-align:center\"> Waiters </h1>\n";
    $num_emp .= print_employee("Waiter");
    echo "<h1 style=\"text-align:center\"> Delivery Boys </h1>\n";
    $num_emp .= print_employee("Delivery_Boy");

    

    echo "<input type=\"submit\" value=\"Delete Selected Employees\">\n";
}
?>

<body background="1.png">
<?php
print_users();
?>
</form>
</body>
</html>
