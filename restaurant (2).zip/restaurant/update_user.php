<!DOCTYPE html>
<html>
<head>
    <title>View Users</title>
    <style type="text/css">
        label {
            float: left;
            width: 300px;
            font-weight: bold;
        }
        input, textarea {
            width: 200px;
            margin-bottom: 9px;
        }
        br {
            clear: left;
        }
    </style>
    <script type="text/javascript" src="check_form_validate.js"></script>
</head>
<body background="1.png">
    <h1 style="text-align:center">Users</h1><br/><br/>
    <?php
        function update_user($user_id)
        {
            $conn = mysqli_connect('localhost', 'root', '', 'restaurant');
            if (!$conn) {
                die('NOT CONNECTED: ' . mysqli_connect_error());
            }

            if (!$user_id) {
                echo "<script type=\"text/javascript\">alert(\"No User Selected!!!\");</script>";
                echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=admin.html\">";
                return;
            }

            $query = "SELECT * FROM USER WHERE User_Id=$user_id";
            $user = mysqli_query($conn, $query);
            if (!$user) {
                die('Query Failed: ' . mysqli_error($conn));
            }

            $num_fields = mysqli_num_fields($user);
            $user_data = mysqli_fetch_assoc($user);

            echo "<form name=\"form1\" action=\"update_user_values.php\" method=\"post\" align=\"center\" onsubmit=\"return checkscript()\">"."\n";
            echo "<table style=\"text-align:center;\" align=\"center\" width=\"400\">"."\n";
            $fieldinfo = mysqli_fetch_fields($user);

            for ($i = 0; $i < $num_fields; $i++) {
                $field = $fieldinfo[$i]->name;
                $value = htmlspecialchars($user_data[$field]);

                echo "<tr>"."\n";
                echo "<td>"."\n";
                echo "<b>".$field."</b>"."\n";
                echo "</td>"."\n";
                echo "<td>"."\n";

                if ($i == 0) {
                    echo "<input type=\"text\" name=\"$field\" value=\"$value\" readonly=\"readonly\">";
                } else {
                    echo "<input type=\"text\" name=\"$field\" value=\"$value\">";
                }

                echo "</td>"."\n";
                echo "</tr>"."\n";
            }
            echo "</table>"."\n"."<br/>";
            echo "<input type=\"submit\" name=\"submitbutton\" value=\"Update\">"."\n";
            echo "</form>"."\n";

            mysqli_free_result($user);
            mysqli_close($conn);
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST["user"])) {
            update_user(intval($_POST["user"]));
        }
    ?>
</body>
</html>
