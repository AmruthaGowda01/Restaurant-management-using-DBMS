<!DOCTYPE html>
<html>
<head>
    <title>Update Employee</title>
</head>
<body background="1.png">
    <script type="text/javascript">
        function done() {
            alert("Employee Updated!!!");
        }
    </script>
    <?php
        function update_emp_values($emp_type, $emp_id, $fname, $lname, $contact, $address, $salary, $sex, $bdate, $join_date)
        {
            // Establishing database connection
            $conn = mysqli_connect('localhost', 'root', '', 'restaurant');
            if (!$conn) {
                die('Connection failed: ' . mysqli_connect_error());
            }

            // Escape user input to prevent SQL injection
            $emp_type = mysqli_real_escape_string($conn, $emp_type);
            $emp_id = intval($emp_id);
            $fname = mysqli_real_escape_string($conn, $fname);
            $lname = mysqli_real_escape_string($conn, $lname);
            $contact = mysqli_real_escape_string($conn, $contact);
            $address = mysqli_real_escape_string($conn, $address);
            $salary = mysqli_real_escape_string($conn, $salary);
            $sex = mysqli_real_escape_string($conn, $sex);
            $bdate = mysqli_real_escape_string($conn, $bdate);
            $join_date = mysqli_real_escape_string($conn, $join_date);

            // Check if employee type is 'COOK' and add Specialization field
            if ($emp_type == 'COOK') {
                $specialization = mysqli_real_escape_string($conn, $_POST["Specialization"]);
                $query = "UPDATE $emp_type SET Fname = ?, Lname = ?, Contact = ?, Address = ?, Salary = ?, Sex = ?, Bdate = ?, Join_Date = ?, Specialization = ? WHERE {$emp_type}_id = ?";
                $stmt = mysqli_prepare($conn, $query);
                mysqli_stmt_bind_param($stmt, 'sssssssssi', $fname, $lname, $contact, $address, $salary, $sex, $bdate, $join_date, $specialization, $emp_id);
            } else {
                $query = "UPDATE $emp_type SET Fname = ?, Lname = ?, Contact = ?, Address = ?, Salary = ?, Sex = ?, Bdate = ?, Join_Date = ? WHERE {$emp_type}_id = ?";
                file_put_contents("qq.txt", " $fname, $lname, $contact, $address, $salary, $sex, $bdate, $join_date, $emp_id");
				$stmt = mysqli_prepare($conn, $query);
                mysqli_stmt_bind_param($stmt, 'ssssssssi', $fname, $lname, $contact, $address, $salary, $sex, $bdate, $join_date, $emp_id);
            }

            // Execute the query and check if successful
            if (mysqli_stmt_execute($stmt)) {
                echo "<script type=\"text/javascript\">done();</script>";
            } else {
                echo "Error: " . mysqli_error($conn);
            }

            // Close the connection
            mysqli_stmt_close($stmt);
            mysqli_close($conn);
        }

        // Call the function to update employee values
        update_emp_values(
            $_POST["emp_type"],
            $_POST["emp_id"],
            $_POST["Fname"],
            $_POST["Lname"],
            $_POST["Contact"],
            $_POST["Address"],
            $_POST["Salary"],
            $_POST["Sex"],
            $_POST["Bdate"],
            $_POST["Join_Date"]
        );
    ?>
    <meta HTTP-EQUIV="REFRESH" content="0; url=admin.html">
</body>
</html>
