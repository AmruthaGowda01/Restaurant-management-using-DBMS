<html>
<title>Delete Menu Items</title>
<h1 style="text-align:center">Delete Menu Items</h1><br/><br/>
<style type="text/css">
label{
    float: left;
    width: 120px;
    font-weight: bold;
}
input, textarea{
    width: 200px;
    margin-bottom: 9px;
}
br{
    clear: left;
}
</style>
<body background="1.png">
<?php
function delete_menu($menu_ids)
{   
    // Establish a connection to the MySQL database using mysqli
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');
    
    // Check if the connection is successful
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }
    
    // Check if the array of menu IDs is not empty
    if (empty($menu_ids)) {
        echo "<script type=\"text/javascript\">\n";
        echo "alert(\"No Items Selected!!!\");\n";
        echo "</script>\n";
        echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=admin.html\">\n";
    } else {
        // Iterate over each selected menu ID and delete the corresponding item
        foreach ($menu_ids as $menu_id) {
            // Prepare the DELETE query to avoid SQL injection
            $query = "DELETE FROM MENU WHERE Menu_Id = ?";
            $stmt = $dbc->prepare($query);
            $stmt->bind_param("i", $menu_id); // Bind the menu ID as an integer
            $stmt->execute();
        }

        // Provide feedback to the user
        echo "<script type=\"text/javascript\">\n";
        echo "alert(\"Selected Items Deleted!!!\");\n";
        echo "</script>\n";
        echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=admin.html\">\n";
    }

    // Close the database connection
    $dbc->close();
}

// Check if the form was submitted with selected menu items
if (isset($_POST['menu'])) {
    delete_menu($_POST['menu']);
}
?>
</body>
</html>
