<html>
<title>Update Table</title>
<?php
function update_table_values($table_num, $details)
{
    // Create a connection to the MySQL database using MySQLi
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');

    // Check for connection errors
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }

    // Prepare the SQL query to update the table details
    $query = "UPDATE `TABLES` SET `Details`=? WHERE `Table_Number`=?";

    // Prepare the statement
    if ($stmt = $dbc->prepare($query)) {
        // Bind the parameters ('s' for string, 'i' for integer)
        $stmt->bind_param('si', $details, $table_num);

        // Execute the query
        if ($stmt->execute()) {
            // Success message
            echo "<script type=\"text/javascript\">" . "\n";
            echo "alert(\"Table Updated !!!\");" . "\n";
            echo "</script>" . "\n";
        } else {
            echo "<script type=\"text/javascript\">" . "\n";
            echo "alert(\"Error updating table.\");" . "\n";
            echo "</script>" . "\n";
        }

        // Close the prepared statement
        $stmt->close();
    } else {
        // Prepare failed
        echo "<script type=\"text/javascript\">" . "\n";
        echo "alert(\"Error preparing statement.\");" . "\n";
        echo "</script>" . "\n";
    }

    // Close the database connection
    $dbc->close();
}

// Call the function with values from the form
update_table_values($_POST["Table_Number"], $_POST["Details"]);
?>

<script type="text/javascript">
    function done() {
        alert("Table Updated !!!");
    }
</script>

<body onload="done()" background="1.png">
    <meta HTTP-EQUIV="REFRESH" content="0; url=admin.html">
</body>
</html>
