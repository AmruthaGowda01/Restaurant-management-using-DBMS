<!DOCTYPE html>
<html>
<head>
    <title>Delete Users</title>
    <h1 style="text-align:center">Delete Users</h1><br/><br/>
    <style type="text/css">
        label {
            float: left;
            width: 120px;
            font-weight: bold;
        }
        input, textarea {
            width: 200px;
            margin-bottom: 9px;
        }
        br {
            clear: left;
        }
    </style>
</head>
<body background="1.png">
    <?php
        function delete_users($user_ids)
        {
            // Database connection
            $conn = mysqli_connect('localhost', 'root', '', 'restaurant');
            if (!$conn) {
                die('NOT CONNECTED: ' . mysqli_connect_error());
            }

            // Check if any users are selected
            if (empty($user_ids)) {
                echo "<script type=\"text/javascript\">alert(\"No Users Selected!!!\");</script>";
                echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=admin.html\">";
                return;
            }

            // Prepare and execute delete queries for selected users
            $query = "DELETE FROM USER WHERE User_Id = ?";
            $stmt = mysqli_prepare($conn, $query);
            if (!$stmt) {
                die('Prepared statement failed: ' . mysqli_error($conn));
            }

            // Bind parameters and execute for each selected user
            foreach ($user_ids as $user_id) {
                mysqli_stmt_bind_param($stmt, 'i', $user_id);
                if (!mysqli_stmt_execute($stmt)) {
                    echo "<script type=\"text/javascript\">alert(\"Error deleting user with ID: $user_id\");</script>";
                }
            }

            // Clean up and close the connection
            mysqli_stmt_close($stmt);
            mysqli_close($conn);

            // Success message
            echo "<script type=\"text/javascript\">alert(\"Selected Users Deleted!!!\");</script>";
            echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=admin.html\">";
        }

        // Call the function with user IDs from the POST request
        delete_users($_POST["user"]);
    ?>
</body>
</html>
