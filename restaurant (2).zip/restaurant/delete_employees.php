<html>
<title>Delete Employees</title>
<h1 style="text-align:center"> Delete Employees </h1><br/><br/>
<style type="text/css">
label {
    float: left;
    width: 120px;
    font-weight: bold;
}
input, textarea {
    width: 200px;
    margin-bottom: 9px;
}
br {
    clear: left;
}
</style>

<body background="1.png">
<?php
// Function to delete employee based on type and ID
function delete_emp($emp_type, $id)
{
    $num_users = count($id);
    $id_type = $emp_type . "_Id";
	file_put_contents("qq.txt", $id_type);
    
    // Create a connection to the MySQL database using mysqli
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }

    for ($i = 0; $i < $num_users; $i++) {
        $query = "DELETE FROM $emp_type WHERE $id_type = ?";
        
        // Prepare and bind the query to prevent SQL injection
        if ($stmt = $dbc->prepare($query)) {
            $stmt->bind_param('i', $id[$i]); // 'i' stands for integer type
            $stmt->execute();
            $stmt->close();
        } else {
            echo "Error in query preparation: " . $dbc->error;
        }
    }
    return $num_users;
}

// Function to delete employees from all employee types
function delete_employees($manager_id, $cook_id, $waiter_id, $delivery_boy_id, $cashier_id)
{
    // Create a connection to the MySQL database using mysqli
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }
    
    $count_deleted = 0;

    // Check if each employee type ID array is not empty, then delete the employees
    if (!empty($manager_id)) {
        $count_deleted += delete_emp("Manager", $manager_id);
    }
    if (!empty($cashier_id)) {
        $count_deleted += delete_emp("Cashier", $cashier_id);
    }
    if (!empty($cook_id)) {
        $count_deleted += delete_emp("Cook", $cook_id);
    }
    if (!empty($waiter_id)) {
        $count_deleted += delete_emp("Waiter", $waiter_id);
    }
    if (!empty($delivery_boy_id)) {
        $count_deleted += delete_emp("Delivery_Boy", $delivery_boy_id);
    }
    
    // Provide feedback to the user
    echo "<script type=\"text/javascript\">\n";
    if ($count_deleted) {
        echo "alert(\"Selected Employees Deleted!!!\");\n";
    } else {
        echo "alert(\"No Employees Selected!!!\");\n";
    }
    echo "</script>\n";
    
    // Redirect to admin page after deletion
    echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=admin.html\">\n";
}

// Call the delete function with the form data
delete_employees(
    isset($_POST["Manager"]) ? $_POST["Manager"] : [],
    isset($_POST["Cook"]) ? $_POST["Cook"] : [],
    isset($_POST["Waiter"]) ? $_POST["Waiter"] : [],
    isset($_POST["Delivery_Boy"]) ? $_POST["Delivery_Boy"] : [],
    isset($_POST["Cashier"]) ? $_POST["Cashier"] : []
);

?>
</body>
</html>
