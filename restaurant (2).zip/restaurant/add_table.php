<html>
<title>Add Tables</title>
<?php
function add_table($table_num, $details)
{
    // Create a connection to the MySQL database using MySQLi
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');
    
    // Check for connection errors
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }
    
    // Check if the table number already exists
    $check = "SELECT * FROM `TABLES` WHERE Table_Number = ?";
    $stmt = $dbc->prepare($check);
    if ($stmt === false) {
        die('Statement preparation failed: ' . $dbc->error);
    }
    
    $stmt->bind_param("i", $table_num); // Bind the table number as an integer
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        // Table number already exists
        echo "<script type=\"text/javascript\">" . "\n";
        echo "alert(\"Table Number Already Exists!!!\");" . "\n";
        echo "</script>" . "\n";
        $stmt->close();
        $dbc->close();
        return;
    }
    
    // Insert the new table into the database
    $query = "INSERT INTO `TABLES` (`Table_Number`, `Details`) VALUES (?, ?)";
    $stmt = $dbc->prepare($query);
    if ($stmt === false) {
        die('Statement preparation failed: ' . $dbc->error);
    }
    
    $stmt->bind_param("is", $table_num, $details); // Bind the table number as integer and details as string
    $stmt->execute();
    
    // Show success message
    echo "<script type=\"text/javascript\">" . "\n";
    echo "alert(\"New Table Added!!!\");" . "\n";
    echo "</script>" . "\n";
    
    // Close the statement and the connection
    $stmt->close();
    $dbc->close();
}
add_table(
    $_POST["Table_Number"],
    $_POST["Details"]
);
?>
<body background="1.png">
<meta HTTP-EQUIV="REFRESH" content="0; url=admin.html">
</body>
</html>
