<html>
<title>Update Menu</title>
<style type="text/css">
label{
    float: left;
    width: 300px;
    font-weight: bold;
}
input, textarea{
    width: 200px;
    margin-bottom: 9px;
}
br{
    clear: left;
}
</style>
<script type="text/javascript" src="check_form_validate.js"></script>

<h1 style="text-align:center">Update Menu</h1><br/><br/>
<?php
// Function to update the menu item
function update_menu($menu_id)
{
    // Establish a connection to the MySQL database using mysqli
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }

    if (!$menu_id) {
        echo "<script type=\"text/javascript\">"."\n";
        echo "alert(\"No Item Selected!!!\");"."\n";
        echo "</script>"."\n";
        echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=admin.html\">";
        return;
    }

    // Prepare the SQL query to fetch the item details by menu ID
    $query = $dbc->prepare("SELECT * FROM MENU WHERE Menu_Id = ?");
    $query->bind_param("i", $menu_id); // Bind the menu_id as an integer
    $query->execute();
    $result = $query->get_result();

    if ($result->num_rows === 0) {
        echo "<script type=\"text/javascript\">"."\n";
        echo "alert(\"Menu item not found!!!\");"."\n";
        echo "</script>"."\n";
        return;
    }

    $row = $result->fetch_assoc();

    // Start the form to update menu item
    echo "<form name = \"form1\" action = \"update_menu_values.php\" method =\"post\" align=\"center\" onsubmit=\"return checkscript()\">"."\n";
    echo "<table style=\"text-align:center;\" align=\"center\" width=\"400\">"."\n";

    // Loop through the fields and display them
    foreach ($row as $field => $value) {
        echo "<tr>\n";
        echo "<td>\n";
        echo "<b>" . ucfirst(str_replace('_', ' ', $field)) . "</b>\n"; // Displaying field name nicely
        echo "</td>\n";
        echo "<td>\n";

        // If it's the menu_id field, make it readonly
        if ($field == 'Menu_Id') {
            echo "<input type=\"text\" name=\"$field\" value=\"$value\" >";
        } else {
            echo "<input type=\"text\" name=\"$field\" value=\"$value\">";
        }

        echo "</td>\n";
        echo "</tr>\n";
    }

    echo "</table>"."\n"."<br/>";

    // Submit button for updating the menu item
    echo "<input type=\"submit\" name=\"submitbutton\" value=\"Update\">"."\n";
    echo "</form>"."\n";
}

?>
<body background="1.png">
<?php
// Call the function with the menu_id from the form
if (isset($_POST["menu_id"])) {
    update_menu(intval($_POST["menu_id"]));  // Ensuring the menu_id is an integer
}
?>
</body>
</html>
