<html>
<title> ADD MENU ITEMS </title>
<?php
function add_ingredient($name, $quantity, $desc, $supp_name)
{
    // Establish a connection using mysqli
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');
    
    // Check if the connection was successful
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }

    // Prepare the SQL query with placeholders for parameters
    $query = "INSERT INTO `INGREDIENT` (`Name`, `Quantity`, `Description`, `Supp_Name`) VALUES (?, ?, ?, ?)";

    // Prepare the statement
    $stmt = $dbc->prepare($query);
    if ($stmt === false) {
        die('MySQL prepare error: ' . $dbc->error);
    }

    // Bind the parameters to the query
    $stmt->bind_param("ssss", $name, $quantity, $desc, $supp_name); // "ssss" indicates four string parameters

    // Execute the query
    if ($stmt->execute()) {
        echo "<script type=\"text/javascript\">alert('New Ingredient Added!!!');</script>";
    } else {
        echo "<script type=\"text/javascript\">alert('Error adding ingredient: " . $stmt->error . "');</script>";
    }

    // Close the statement and the connection
    $stmt->close();
    $dbc->close();
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    add_ingredient(
        $_POST["Name"],
        $_POST["Quantity"],
        $_POST["Description"],
        $_POST["Supplier_name"]
    );
}
?>
<body onload="done()" background="1.png">
<meta HTTP-EQUIV="REFRESH" content="0; url=admin.html">
</body>
</html>
