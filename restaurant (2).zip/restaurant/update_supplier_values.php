<html>
<title>Update Supplier</title>

<?php
function update_supplier_values($fname, $lname, $address, $contact, $details)
{
    // Establish database connection using mysqli
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');

    // Check for connection error
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }

    // Prepare and bind the update query to prevent SQL injection
    $query = "UPDATE `SUPPLIER` SET `Contact`=?, `Address`=?, `Details`=? WHERE `Fname`=? AND `Lname`=?";
    $stmt = $dbc->prepare($query);

    // Bind the parameters ('s' stands for string type)
    $stmt->bind_param('sssss', $contact, $address, $details, $fname, $lname);

    // Execute the query
    if ($stmt->execute()) {
        echo "<script type=\"text/javascript\">" . "\n";
        echo "alert(\"Supplier Updated !!!\");" . "\n";
        echo "</script>" . "\n";
    } else {
        echo "<script type=\"text/javascript\">" . "\n";
        echo "alert(\"Error updating supplier!\");" . "\n";
        echo "</script>" . "\n";
    }

    // Close the statement and connection
    $stmt->close();
    $dbc->close();
}

update_supplier_values(
    $_POST["Fname"],
    $_POST["Lname"],
    $_POST["Address"],
    $_POST["Contact"],
    $_POST["Details"]
);
?>

<script type="text/javascript">
    function done() {
        alert("Supplier Updated !!!");
    }
</script>

<body onload="done()" background="1.png">
<meta HTTP-EQUIV="REFRESH" content="0; url=admin.html">
</body>
</html>
