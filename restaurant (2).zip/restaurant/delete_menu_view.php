<html>
<title>Delete Menu Items</title>
<h1 style="text-align:center">Delete Menu Items</h1>
<style type="text/css">
div.div1
{
    text-align:center;
    font-weight: bold;
}
</style>
<style type="text/css">
label{
    float: left;
    width: 120px;
    font-weight: bold;
}
input, textarea{
    width: 200px;
    margin-bottom: 9px;
}
br{
    clear: left;
}
</style>

<?php
// Function to print the menu items
function print_menu()
{
    // Establish database connection using mysqli
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }

    $query = "SELECT * FROM MENU";
    $result = $dbc->query($query);

    if ($result->num_rows == 0) {
        echo "<script type=\"text/javascript\">"."\n";
        echo "alert(\"No Items In Menu !!!\");"."\n";
        echo "</script>"."\n";
        echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=admin.html\">"."\n";
        return;
    }

    // Start form to delete menu items
    echo "<form action=\"delete_menu.php\" method=\"post\" align=\"center\">"."\n";
    echo "<table border=\"4\" style=\"text-align:center;\" align=\"center\" width=\"900\">"."\n";
    echo "<tr>\n";
    // Display the column headers
    while ($field = $result->fetch_field()) {
        echo "<td>" . $field->name . "</td>\n";
    }
    echo "<td>Select To Delete</td>\n";
    echo "</tr>\n";

    // Display the menu items with a checkbox to select for deletion
    while ($row = $result->fetch_assoc()) {
        echo "<tr>\n";
        foreach ($row as $key => $value) {
            echo "<td>" . $value . "</td>\n";
        }
        echo "<td><input type=\"checkbox\" name=\"menu[]\" value=\"" . $row['Menu_Id'] . "\"></td>\n";
        echo "</tr>\n";
    }
    echo "</table>\n";
    echo "<br/><input type=\"submit\" value=\"Delete Selected Items\">\n";
    echo "</form>\n";

    // Close the connection
    $dbc->close();
}
?>

<body background="1.png">
<?php
// Call the function to display the menu items
print_menu();
?>
</body>
</html>
