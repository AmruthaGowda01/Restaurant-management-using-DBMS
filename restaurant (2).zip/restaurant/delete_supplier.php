<html>
<title>Delete Suppliers</title>
<h1 style="text-align:center"> Delete Suppliers </h1><br/><br/>

<style type="text/css">
label {
    float: left;
    width: 120px;
    font-weight: bold;
}
input, textarea {
    width: 200px;
    margin-bottom: 9px;
}
br {
    clear: left;
}
</style>

<body background="1.png">

<?php
function delete_supplier($suppliers) {    
    // Establishing database connection using mysqli
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');
    
    // Checking for connection error
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }

    // If no suppliers are selected
    if (empty($suppliers)) {
        echo "<script type=\"text/javascript\">\n";
        echo "alert(\"No Suppliers Selected!!!\");\n";
        echo "</script>\n";
        echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=admin.html\">\n";
        return;
    } else {
        // Deleting selected suppliers
        foreach ($suppliers as $supplier) {
            // Prepared statement to prevent SQL injection
            $query = $dbc->prepare("DELETE FROM SUPPLIER WHERE Contact = ?");
            $query->bind_param("s", $supplier); // "s" specifies the type (string) for the parameter
            $query->execute();
        }
        echo "<script type=\"text/javascript\">\n";
        echo "alert(\"Selected Suppliers Deleted!!!\");\n";
        echo "</script>\n";
        echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=admin.html\">\n";
    }

    // Closing the database connection
    $dbc->close();
}

// Calling the function to delete suppliers
if (isset($_POST['supplier'])) {
    delete_supplier($_POST['supplier']);
}
?>

</body>
</html>
