<html>
<title>Delete Tables</title>
<h1 style="text-align:center">Delete Tables</h1><br/><br/>
<style type="text/css">
label {
    float: left;
    width: 120px;
    font-weight: bold;
}
input, textarea {
    width: 200px;
    margin-bottom: 9px;
}
br {
    clear: left;
}
</style>
<body background="1.png">
<?php
function delete_table($tables)
{    
    // Create a connection to the MySQL database using MySQLi
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');

    // Check for connection errors
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }

    // Check if any tables were selected
    if (empty($tables)) {
        echo "<script type=\"text/javascript\">"."\n";
        echo "alert(\"No Tables Selected!!!\");"."\n";
        echo "</script>"."\n";
        echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=admin.html\">"."\n";
    } else {
        // Prepare the DELETE statement to delete tables
        $stmt = $dbc->prepare("DELETE FROM TABLES WHERE Table_Number = ?");
        $stmt->bind_param("i", $table_number);

        // Loop through each selected table and delete it
        foreach ($tables as $table_number) {
            $stmt->execute();
        }

        // Close the prepared statement
        $stmt->close();

        // Display success message and redirect
        echo "<script type=\"text/javascript\">"."\n";
        echo "alert(\"Selected Tables Deleted!!!\");"."\n";
        echo "</script>"."\n";
        echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=admin.html\">"."\n";
    }

    // Close the database connection
    $dbc->close();
}

// Call the function to delete the selected tables
delete_table($_POST['table']);
?>
</body>
</html>
