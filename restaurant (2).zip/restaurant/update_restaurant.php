<html>
<title> Update Restaurant </title>
<style type="text/css">
label {
    float: left;
    width: 300px;
    font-weight: bold;
}
input, textarea {
    width: 200px;
    margin-bottom: 9px;
}
br {
    clear: left;
}
</style>
<script type="text/javascript" src="check_form_validate.js"></script>

<h1 style="text-align:center"> Update Restaurant </h1><br/>
<?php
function update_restaurant()
{
    // Create a new MySQLi connection
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');

    // Check for connection errors
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }

    // Prepare the select query
    $query = "SELECT * from RESTAURANT;";
    
    // Execute the query
    if ($result = $dbc->query($query)) {
        // Check if data exists
        if ($result->num_rows > 0) {
            // Start form
            echo "<form name=\"form1\" action=\"update_restaurant_values.php\" method=\"post\" align=\"center\" onsubmit=\"return checkscript()\">" . "\n";
            echo "<table style=\"text-align:center;\" align=\"center\" width=\"400\">" . "\n";

            // Fetch associative array of the first row
            $row = $result->fetch_assoc();

            // Iterate through each field and create form inputs
            foreach ($row as $field => $value) {
                echo "<tr>" . "\n";
                echo "<td>" . "\n";
                echo "<b>" . $field . "</b>" . "\n";
                echo "</td>" . "\n";
                echo "<td>" . "\n";
                // If field is not the primary key, allow editing
                if ($field != 'Rest_Name') {
                    echo "<input type=\"text\" name=\"$field\" value=\"$value\">" . "\n";
                } else {
                    echo "<input type=\"text\" name=\"$field\" value=\"$value\" readonly=\"readonly\">" . "\n";
                }
                echo "</td>" . "\n";
                echo "</tr>" . "\n";
            }
            echo "</table>" . "\n" . "<br/>";
            echo "<input type=\"submit\" name=\"submitbutton\" value=\"Update\">" . "\n";
            echo "</form>" . "\n";
        } else {
            echo "<p>No restaurant data found to update.</p>";
        }
    } else {
        echo "<p>Error: " . $dbc->error . "</p>";
    }

    // Close the connection
    $dbc->close();
}
?>
<body background="1.png">
<?php
update_restaurant();
?>
</body>
</html>
