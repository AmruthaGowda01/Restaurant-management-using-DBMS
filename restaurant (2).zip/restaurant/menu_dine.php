<html>
<title> Select Menu Items</title>
<h1 style="text-align:center"> Select Menu Items</h1>
<style type="text/css">
div.div1
{
    text-align:center;
    font-weight: bold;
}
</style>
<style type="text/css">
label{
    float: left;
    width: 120px;
    font-weight: bold;
}
input, textarea{
    width: 200px;
    margin-bottom: 9px;
}
br{
    clear: left;
}
</style>
<script type="text/javascript" src="check_form_validate.js"></script>
<?php
function print_menu()
{
    // Establish MySQLi connection
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');

    // Check for connection errors
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }

    // Fetch menu items
    $query = "SELECT * FROM MENU";
    $menu = $dbc->query($query);

    // Check if menu has items
    if ($menu->num_rows == 0) {
        echo "<script type=\"text/javascript\">" . "\n";
        echo "alert(\"No Items In Menu !!!\");" . "\n";
        echo "</script>" . "\n";
        echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=user.html\">" . "\n";
        return;
    }

    // Get customer ID
    $cust_id = intval($_POST["cust_id"]);

    // Fetch customer details
    $stmt = $dbc->prepare("SELECT * FROM CUSTOMER WHERE Customer_Id = ?");
    $stmt->bind_param("i", $cust_id);
    $stmt->execute();
    $res = $stmt->get_result();

    // Check if customer exists
    if ($res->num_rows == 0) {
        echo "Customer not found!";
        return;
    }

    // Display customer details
    $customer = $res->fetch_assoc();
    echo "<form name=\"form1\" action=\"menu_bill_dine_confirm.php\" method=\"post\" align=\"center\" onsubmit=\"return checkscript()\">" . "\n";
    echo "<table border=\"4\" style=\"text-align:center;\" align=\"center\" width=\"900\">" . "\n";
    foreach ($customer as $field => $value) {
        echo "<tr>\n";
        echo "<td>\n";
        echo $field;
        echo "</td>\n";
        echo "<td>\n";
        echo "<input type=\"text\" name=\"$field\" value=\"$value\" readonly=\"readonly\">";
        echo "</td>\n";
        echo "</tr>\n";
    }
    echo "</table>" . "\n" . "<br/><br/>\n";

    // Display menu items
    echo "<table border=\"4\" style=\"text-align:center;\" align=\"center\" width=\"900\">" . "\n";
    echo "<tr>\n";
    while ($field_info = $menu->fetch_field()) {
        echo "<td>\n";
        echo $field_info->name;
        echo "</td>\n";
    }
    echo "<td>\n";
    echo "Select Items" . "\n";
    echo "</td>\n";
    echo "</tr>\n";

    // Display each menu item with checkbox
    while ($row = $menu->fetch_assoc()) {
        echo "<tr>\n";
        foreach ($row as $column => $value) {
            echo "<td>\n";
            echo $value . " " . "\n";
            echo "</td>\n";
        }
        echo "<td>\n";
        $id = $row['Menu_Id'];  // Assuming Menu_Id is the first column
        echo "<input type=\"checkbox\" name=\"menu[]\" value=\"$id\"><br/>" . "\n";
        echo "</td>\n";
        echo "</tr>\n";
    }

    echo "</table>" . "\n" . "<br/>";
    echo "<input type=\"submit\" value=\"Select Items\">" . "\n";
    echo "</form>";

    // Close the statement and connection
    $stmt->close();
    $dbc->close();
}
?>
<body background="1.png">
<?php
print_menu();
?>
</body>
</html>
