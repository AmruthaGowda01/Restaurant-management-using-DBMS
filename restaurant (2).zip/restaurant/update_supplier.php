<html>
<title> Update Supplier </title>
<style type="text/css">
label{
    float: left;
    width: 300px;
    font-weight: bold;
}
input, textarea{
    width: 200px;
    margin-bottom: 9px;
}
br{
    clear: left;
}
</style>
<script type="text/javascript" src="check_form_validate.js"></script>

<h1 style="text-align:center"> Update Supplier </h1><br/><br/>

<?php
function update_supplier($supplier_contact)
{
    // Establish connection using mysqli
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');

    // Check for connection error
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }

    // Check if supplier contact is provided
    if (!$supplier_contact) {
        echo "<script type=\"text/javascript\">"."\n";
        echo "alert(\"No Supplier Selected!!!\");"."\n";
        echo "</script>"."\n";
        echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=admin.html\">";
        return;
    }

    // Query to get the supplier details based on contact
    $query = "SELECT * FROM SUPPLIER WHERE Contact = ?";
    $stmt = $dbc->prepare($query);
    $stmt->bind_param('s', $supplier_contact); // 's' indicates the type of the parameter (string)
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if supplier exists
    if ($result->num_rows == 0) {
        echo "<script type=\"text/javascript\">"."\n";
        echo "alert(\"No Supplier Found!!!\");"."\n";
        echo "</script>"."\n";
        echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=admin.html\">";
        return;
    }

    // Fetch the supplier data
    $supplier = $result->fetch_assoc();

    // Display the form with the current supplier details
    echo "<form name=\"form1\" action=\"update_supplier_values.php\" method=\"post\" align=\"center\" onsubmit=\"return checkscript()\">"."\n";
    echo "<table style=\"text-align:center;\" align=\"center\" width=\"400\">"."\n";

    foreach ($supplier as $field => $value) {
        // Skip the Contact field, as it is read-only
        if ($field == 'Contact') {
            echo "<tr>\n";
            echo "<td><b>$field</b></td>\n";
            echo "<td><input type=\"text\" name=\"$field\" value=\"$value\" readonly=\"readonly\"></td>\n";
            echo "</tr>\n";
        } else {
            echo "<tr>\n";
            echo "<td><b>$field</b></td>\n";
            echo "<td><input type=\"text\" name=\"$field\" value=\"$value\"></td>\n";
            echo "</tr>\n";
        }
    }

    echo "</table>"."\n"."<br/>";
    echo "<input type=\"submit\" name=\"submitbutton\" value=\"Update\">"."\n";
    echo "</form>"."\n";

    // Close the database connection
    $stmt->close();
    $dbc->close();
}
?>

<body background="1.png">
<?php
update_supplier($_POST["supplier"]);
?>
</body>
</html>
