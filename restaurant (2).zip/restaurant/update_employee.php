<!DOCTYPE html>
<html>
<head>
    <title>Update Employee</title>
    <style type="text/css">
        label {
            float: left;
            width: 300px;
            font-weight: bold;
        }
        input, textarea {
            width: 200px;
            margin-bottom: 9px;
        }
        br {
            clear: left;
        }
    </style>
    <script type="text/javascript" src="check_form_validate.js"></script>
</head>
<body background="1.png">
    <h1 style="text-align:center"> Update Employee </h1><br/><br/>
    <?php
        function update_user($employee) {
            // Establishing database connection
            $conn = mysqli_connect('localhost', 'root', '', 'restaurant');
            if (!$conn) {
                die('Connection failed: ' . mysqli_connect_error());
            }

            if ($employee == "") {
                echo "<script type=\"text/javascript\">" . "\n";
                echo "alert(\"No Employee Selected!!!\");" . "\n";
                echo "</script>" . "\n";
                echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=admin.html\">";
                return;
            }

            // Split employee data to get employee ID and type
            list($emp_id, $emp_type) = explode(",", $employee, 2);
            $emp_id = intval($emp_id);
            $emp_id_type = $emp_type . "_id";

            // Query to get employee data based on employee ID and type
            $query = "SELECT * FROM $emp_type WHERE $emp_id_type = ?";
            $stmt = mysqli_prepare($conn, $query);
            mysqli_stmt_bind_param($stmt, 'i', $emp_id);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);

            if ($result) {
                // Get column names
                $columns = mysqli_fetch_fields($result);

                echo "<form name=\"form1\" action=\"update_employee_values.php\" method=\"post\" align=\"center\" onsubmit=\"return checkscript()\">" . "\n";
                echo "<table style=\"text-align:center;\" align=\"center\" width=\"400\">" . "\n";
                echo "<tr>\n";
                echo "<td><b>Employee Type</b></td>\n";
                echo "<td><input type=\"text\" name=\"emp_type\" value=\"$emp_type\" readonly=\"readonly\"></td>" . "\n";
                echo "</tr>\n";

                // Loop through the fields and generate the form
                while ($row = mysqli_fetch_assoc($result)) {
                    foreach ($row as $field => $value) {
                        echo "<tr>" . "\n";
                        echo "<td>" . "\n";
                        echo "<b>" . ucfirst($field) . "</b>" . "\n";
                        echo "</td>" . "\n";
                        echo "<td>" . "\n";
                        // If it's the first column (emp_id), make it readonly
                        if ($field === $emp_id_type) {
							//echo $field;
                            echo "<input type=\"text\" name=\"emp_id\" value=\"$value\" >" . "\n";
                        } else {
							if (strpos($field, "Id") !== false) {
								echo "<input type=\"text\" name=\"emp_id\" value=\"$value\" >" . "\n";
							}
							else
							     echo "<input type=\"text\" name=\"$field\" value=\"$value\">" . "\n";
                        }
                        echo "</td>" . "\n";
                        echo "</tr>" . "\n";
                    }
                }

                echo "</table>" . "\n" . "<br/>";
                echo "<input type=\"submit\" name=\"submitbutton\" value=\"Update\">" . "\n";
                echo "</form>" . "\n";
            } else {
                echo "<script type=\"text/javascript\">" . "\n";
                echo "alert(\"Employee not found!!!\");" . "\n";
                echo "</script>" . "\n";
            }

            // Close the database connection
            mysqli_close($conn);
        }

        // Call the function to update user based on the POST data
        update_user($_POST["employee"]);
    ?>
</body>
</html>
