<!DOCTYPE html>
<html>
<head>
    <title>Update User</title>
</head>
<body background="1.png">
    <?php
        function update_user_values($user_id, $firstname, $lastname, $password)
        {
            $conn = mysqli_connect('localhost', 'root', '', 'restaurant');
            if (!$conn) {
                die('NOT CONNECTED: ' . mysqli_connect_error());
            }

            $query = "UPDATE `USER` SET `Fname` = ?, `Lname` = ?, `Password` = ? WHERE `User_Id` = ?";
            $stmt = mysqli_prepare($conn, $query);
            if (!$stmt) {
                die('Prepared statement failed: ' . mysqli_error($conn));
            }

            // Bind the parameters
            mysqli_stmt_bind_param($stmt, 'sssi', $firstname, $lastname, $password, $user_id);

            // Execute the query
            if (mysqli_stmt_execute($stmt)) {
                echo "<script type=\"text/javascript\">alert('User Updated !!!');</script>";
            } else {
                echo "<script type=\"text/javascript\">alert('Error updating user.');</script>";
            }

            // Close the statement and connection
            mysqli_stmt_close($stmt);
            mysqli_close($conn);
        }

        // Call the function with user input from POST
        update_user_values(
            intval($_POST["User_Id"]),
            $_POST["Fname"],
            $_POST["Lname"],
            $_POST["Password"]
        );
    ?>
    <meta HTTP-EQUIV="REFRESH" content="0; url=admin.html">
</body>
</html>
