<html>
<title> Update Supplier</title>
<h1 style="text-align:center"> Update Supplier</h1>
<style type="text/css">
div.div1
{
	text-align:center;
	font-weight: bold;
}
</style>
<style type="text/css">
label{
float: left;
width: 120px;
       font-weight: bold;
}
input, textarea{
width: 200px;
       margin-bottom: 9px;
}
br{
clear: left;
}
</style>
<?php
function print_supplier()
{
    // Establish a connection to MySQL database using mysqli with a blank root password
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');
    
    // Check for connection error
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }

    // Query to fetch supplier data
    $query = "SELECT * FROM SUPPLIER";
    $result = $dbc->query($query);

    // Check if there are any suppliers
    if ($result->num_rows == 0) {
        echo "<script type=\"text/javascript\">"."\n";
        echo "alert(\"No Suppliers!!!\");"."\n";
        echo "</script>"."\n";
        echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=admin.html\">"."\n";
        return;
    }

    // Generate the table for displaying suppliers
    echo "<form action=\"update_supplier.php\" method=\"post\" align=\"center\">"."\n";
    echo "<table border=\"4\" style=\"text-align:center;\" align=\"center\" width=\"900\">"."\n";
    
    // Fetch the field names
    $fields = $result->fetch_fields();
    echo "<tr>\n";
    foreach ($fields as $field) {
        echo "<td>" . $field->name . "</td>\n";
    }
    echo "<td>Select To Update</td>\n";
    echo "</tr>\n";

    // Fetch each supplier row
    while ($row = $result->fetch_assoc()) {
        echo "<tr>\n";
        foreach ($row as $key => $value) {
            echo "<td>" . $value . "</td>\n";
        }
        
        // Add a radio button to select the supplier to update
        echo "<td>\n";
        echo "<input type=\"radio\" name=\"supplier\" value=\"" . $row['Contact'] . "\"><br/>\n";
        echo "</td>\n";
        echo "</tr>\n";
    }

    echo "</table>"."\n"."<br/>";
    echo "<input type=\"submit\" value=\"Update Selected Item\">"."\n";
    echo "</form>"."\n";

    // Close the database connection
    $dbc->close();
}
?>
<body background="1.png">
<?php
print_supplier();
?>
</body>
</html>
