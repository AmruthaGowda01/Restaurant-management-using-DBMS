<html>
<title>Update Restaurant</title>
<?php
function update_restaurant_values($name, $location, $contact, $oc_time, $details)
{
    // Create a new MySQLi connection
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');

    // Check for connection errors
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }

    // Prepare the update query with placeholders for parameters
    $query = "UPDATE `RESTAURANT` SET `Opening_Closing_Time` = ?, `Location` = ?, `Contact` = ?, `Details` = ? WHERE `Name` = ?";

    // Prepare the statement
    if ($stmt = $dbc->prepare($query)) {
        // Bind the input parameters to the prepared statement
        $stmt->bind_param("sssss", $oc_time, $location, $contact, $details, $name);

        // Execute the query
        if ($stmt->execute()) {
            echo "<script type=\"text/javascript\">" . "\n";
            echo "alert(\"Restaurant Details Updated !!!\");" . "\n";
            echo "</script>" . "\n";
            echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=admin.html\">" . "\n";
        } else {
            echo "<script type=\"text/javascript\">" . "\n";
            echo "alert(\"Error updating restaurant details: " . $stmt->error . "\");" . "\n";
            echo "</script>" . "\n";
        }

        // Close the prepared statement
        $stmt->close();
    } else {
        echo "<script type=\"text/javascript\">" . "\n";
        echo "alert(\"Error preparing the query: " . $dbc->error . "\");" . "\n";
        echo "</script>" . "\n";
    }

    // Close the database connection
    $dbc->close();
}

// Call the function to update the restaurant details
update_restaurant_values(
    $_POST["Name"],
    $_POST["Location"],
    $_POST["Contact"],
    $_POST["Opening_Closing_Time"],
    $_POST["Details"]
);
?>
</body>
</html>
