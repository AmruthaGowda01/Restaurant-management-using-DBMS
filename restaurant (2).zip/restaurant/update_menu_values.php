<html>
<title>Update Menu</title>
<?php
function update_menu_values($menu_id, $name, $price, $type, $category)
{
    // Establish a connection to the MySQL database using mysqli
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }

    // Prepare the update query with placeholders
    $query = "UPDATE `MENU` SET `Name` = ?, `Price` = ?, `Type` = ?, `Category` = ? WHERE `Menu_Id` = ?";
    
    // Prepare the statement
    $stmt = $dbc->prepare($query);
    if ($stmt === false) {
        die('MySQL prepare failed: ' . $dbc->error);
    }

    // Bind the parameters (s = string, d = double)
    $stmt->bind_param("ssssi", $name, $price, $type, $category, $menu_id);

    // Execute the query
    if ($stmt->execute()) {
        echo "<script type=\"text/javascript\">"."\n";
        echo "alert(\"Menu Updated !!!\");"."\n";
        echo "</script>"."\n";
    } else {
        echo "<script type=\"text/javascript\">"."\n";
        echo "alert(\"Error updating menu item.\");"."\n";
        echo "</script>"."\n";
    }

    // Close the prepared statement and connection
    $stmt->close();
    $dbc->close();
}

// Call the update function
update_menu_values(
    intval($_POST["Menu_Id"]),
    $_POST["Name"],
    $_POST["Price"],
    $_POST["Type"],
    $_POST["Category"]
);
?>
<script type="text/javascript">
    // Function to display alert after update
    function done() {
        alert("Menu Updated !!!");
    }
</script>

<body onload="done()" background="1.png">
    <meta HTTP-EQUIV="REFRESH" content="0; url=admin.html">
</body>
</html>
