<html>
<title> Select Menu Items</title>
<h1 style="text-align:center"> Select Menu Items</h1>
<style type="text/css">
div.div1 {
    text-align:center;
    font-weight: bold;
}
</style>
<style type="text/css">
label {
    float: left;
    width: 120px;
    font-weight: bold;
}
input, textarea {
    width: 200px;
    margin-bottom: 9px;
}
br {
    clear: left;
}
</style>
<script type="text/javascript" src="check_form_validate.js"></script>

<?php
function print_menu() {
    // Create MySQLi connection
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');
    
    // Check for connection errors
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }

    // Query to fetch menu items
    $query = "SELECT * FROM MENU";
    $menu = $dbc->query($query);

    // Check if menu items exist
    if ($menu->num_rows == 0) {
        echo "<script type=\"text/javascript\">";
        echo "alert(\"No Items In Menu !!!\");";
        echo "</script>";
        echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=user.html\">";
        return;
    }

    // Fetch customer details
    $cust_id = intval($_POST["cust_id"]);
    $query = "SELECT * FROM CUSTOMER WHERE Customer_Id = ?";
    
    if ($stmt = $dbc->prepare($query)) {
        $stmt->bind_param("i", $cust_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        // Display customer details
        echo "<form name=\"form1\" action=\"menu_bill_home_delivery_confirm.php\" method=\"post\" align=\"center\" onsubmit=\"return checkscript()\">";
        echo "<table border=\"4\" style=\"text-align:center;\" align=\"center\" width=\"900\">";
        $row = $result->fetch_assoc();
        foreach ($row as $field => $value) {
            echo "<tr><td>$field</td><td><input type=\"text\" name=\"$field\" value=\"$value\" readonly=\"readonly\"></td></tr>";
        }
        echo "</table><br/><br/>";

        // Display menu items
        echo "<table border=\"4\" style=\"text-align:center;\" align=\"center\" width=\"900\">";
        echo "<tr>";
        $menu_fields = $menu->fetch_fields();
        foreach ($menu_fields as $field) {
            echo "<td>" . $field->name . "</td>";
        }
        echo "<td>Select Items</td></tr>";

        // Loop through menu items
        while ($menu_item = $menu->fetch_assoc()) {
            echo "<tr>";
            foreach ($menu_item as $key => $value) {
                echo "<td>$value</td>";
            }
            $id = $menu_item['Menu_Id']; // Assuming 'Id' is the first column
            echo "<td><input type=\"checkbox\" name=\"menu[]\" value=\"$id\"><br/></td>";
            echo "</tr>";
        }
        echo "</table><br/>";
        echo "<input type=\"submit\" value=\"Select Items\">";
        echo "</form>";

        // Close the statement
        $stmt->close();
    }

    // Close database connection
    $dbc->close();
}
?>

<body background="1.png">
<?php
print_menu();
?>
</body>
</html>
