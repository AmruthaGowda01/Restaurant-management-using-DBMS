<html>
<title>Selected Menu Items</title>
<h1 style="text-align:center">Selected Menu Items</h1><br/><br/>
<style type="text/css">
label {
    float: left;
    width: 120px;
    font-weight: bold;
}
input, textarea {
    width: 200px;
    margin-bottom: 9px;
}
br {
    clear: left;
}
</style>
<script>
function readOnlyCheckBox() {
    return false;
}
</script>
<!--script type="text/javascript" src="check_form_validate.js"></script-->

<body background="1.png">
<?php
function select_menu($menu_id, $cust_id, $fname, $lname, $contact, $email_id) {
    // Create MySQLi connection
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');
    
    // Check for connection errors
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }

    // If no menu items are selected
    if (empty($menu_id)) {
        echo "<script type=\"text/javascript\">";
        echo "alert(\"No Items Selected!!!\");";
        echo "</script>";
        echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=ask_contact_home_delivery.php\">";
        return;
    } else {
        // Prepare and execute query to fetch customer details
        $query = "SELECT * FROM CUSTOMER WHERE Customer_Id = ?";
        if ($stmt = $dbc->prepare($query)) {
            $stmt->bind_param("i", $cust_id);
            $stmt->execute();
            $res = $stmt->get_result();
            $num_fields = $res->field_count;

            // Display customer details in a form
            echo "<form name=\"form1\" action=\"pay_bill_home_delivery.php\" method=\"post\" align=\"center\" onsubmit=\"return checkscript()\">";
            echo "<table border=\"4\" style=\"text-align:center;\" align=\"center\" width=\"900\">";
            $row = $res->fetch_assoc();
            foreach ($row as $field => $value) {
                echo "<tr><td>$field</td><td><input type=\"text\" name=\"$field\" value=\"$value\" readonly=\"readonly\"></td></tr>";
            }
            echo "<tr><td>Address</td><td><input type=\"text\" name=\"address\"></td></tr>";
            echo "</table><br/><br/>";

            // Query to fetch menu items
            $query = "SELECT * FROM MENU";
            $menu = $dbc->query($query);
            $num_fields = $menu->field_count;
            echo "<table border=\"4\" style=\"text-align:center;\" align=\"center\" width=\"900\">";
            echo "<tr>";
            // Display menu headers
            while ($field = $menu->fetch_field()) {
                echo "<td>" . $field->name . "</td>";
            }
            echo "<td>Selected</td><td>Quantity</td></tr>";

            // Display selected menu items
            foreach ($menu_id as $id) {
                $query = "SELECT * FROM MENU WHERE Menu_Id = ?";
                if ($stmt = $dbc->prepare($query)) {
                    $stmt->bind_param("i", $id);
                    $stmt->execute();
                    $menu_result = $stmt->get_result();
                    $menu_item = $menu_result->fetch_assoc();
                    echo "<tr>";
                    foreach ($menu_item as $key => $value) {
                        echo "<td>$value</td>";
                    }
                    echo "<td><input type=\"checkbox\" name=\"menu[]\" value=\"$id\" checked=\"checked\" onClick=\"return readOnlyCheckBox()\"></td>";
                    echo "<td><input type=\"text\" name=\"quantity[]\" value=\"1\"></td>";
                    echo "</tr>";
                }
            }

            echo "</table><br/>";
            echo "<input type=\"submit\" value=\"Confirm\">";
            echo "</form>";

            $stmt->close();
        }
    }

    // Close the connection
    $dbc->close();
}
?>

<?php
// Call the function with POST data
select_menu(
    $_POST["menu"],
    $_POST["Customer_Id"],
    $_POST["Fname"],
    $_POST["Lname"],
    $_POST["Contact"],
    $_POST["Email_Id"]
);
?>
</body>
</html>
