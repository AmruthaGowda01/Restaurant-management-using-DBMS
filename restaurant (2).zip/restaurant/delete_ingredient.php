<html>
<title>Delete Ingredients</title>
<h1 style="text-align:center">Delete Ingredients</h1><br/><br/>
<style type="text/css">
label{
    float: left;
    width: 120px;
    font-weight: bold;
}
input, textarea{
    width: 200px;
    margin-bottom: 9px;
}
br{
    clear: left;
}
</style>
<body background="1.png">
<?php
function delete_ingredient($ing)
{
    // Create a connection to the MySQL database using MySQLi
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');
    
    // Check for connection errors
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }
    
    // Check if ingredients are selected
    if (empty($ing)) {
        echo "<script type=\"text/javascript\">" . "\n";
        echo "alert(\"No Ingredients Selected!!!\");" . "\n";
        echo "</script>" . "\n";
        echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=admin.html\">" . "\n";
    } else {
        // Loop through selected ingredients and delete them
        $num_ing = count($ing);
        $stmt = $dbc->prepare("DELETE FROM INGREDIENT WHERE Ingredient_Id = ?");
        if ($stmt === false) {
            die('Statement preparation failed: ' . $dbc->error);
        }
        
        for ($i = 0; $i < $num_ing; $i++) {
            $stmt->bind_param("i", $ing[$i]); // Bind the ingredient ID as an integer
            $stmt->execute();
        }

        // Close the prepared statement
        $stmt->close();

        // Show success message and redirect
        echo "<script type=\"text/javascript\">" . "\n";
        echo "alert(\"Selected Ingredients Deleted!!!\");" . "\n";
        echo "</script>" . "\n";
        echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=admin.html\">" . "\n";
    }
    
    // Close the database connection
    $dbc->close();
}

// Call the function with POST data
delete_ingredient($_POST['ingredient']);
?>
</body>
</html>
