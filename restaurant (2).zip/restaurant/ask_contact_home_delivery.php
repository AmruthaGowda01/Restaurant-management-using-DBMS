<html>
<title>Check Contact</title>
<?php
function check_booking_contact($contact)
{
    // Create a new MySQLi connection
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');

    // Check for connection errors
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }

    // Check if the contact number is provided
    if (empty($contact)) {
        echo "<script type=\"text/javascript\">";
        echo "alert(\"No Contact Added!!!\");";
        echo "</script>";
        echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=user.html\">";
        return;
    }

    // Validate the contact number (ensure it's numeric)
    if (!is_numeric($contact)) {
        echo "<script type=\"text/javascript\">";
        echo "alert(\"Invalid Contact Number!!!\");";
        echo "</script>";
        echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=user.html\">";
        return;
    }

    // Check if the customer already exists
    $query = "SELECT Customer_Id FROM CUSTOMER WHERE Contact = ?";
    if ($stmt = $dbc->prepare($query)) {
        $stmt->bind_param("i", $contact); // Bind the contact as an integer
        $stmt->execute();
        $stmt->store_result();
        $num_items = $stmt->num_rows;

        // If customer exists, retrieve their ID
        if ($num_items > 0) {
            $stmt->bind_result($cust_id);
            $stmt->fetch();

            // Submit the customer ID to the home delivery form
            echo "<form id=\"form1\" name=\"form1\" action=\"menu_home_delivery.php\" method=\"post\">";
            echo "<input type=\"text\" name=\"cust_id\" value=\"$cust_id\">";
            echo "<input type=\"submit\" name=\"submitbutton\" value=\"Check\">";
            echo "</form>";
            echo "<script type=\"text/javascript\">";
            echo "document.getElementById(\"form1\").submit();";
            echo "</script>";
        } else {
            // If customer doesn't exist, ask to add the customer
            echo "<form id=\"form1\" name=\"form1\" action=\"add_customer_home_delivery.php\" method=\"post\">";
            echo "<input type=\"text\" name=\"contact\" value=\"$contact\">";
            echo "<input type=\"submit\" name=\"submitbutton\" value=\"Check\">";
            echo "</form>";
            echo "<script type=\"text/javascript\">";
            echo "document.getElementById(\"form1\").submit();";
            echo "</script>";
        }
        $stmt->close();
    }

    // Close the database connection
    $dbc->close();
}
?>

<body background="1.png">
<?php
// Call the function to check the booking contact
check_booking_contact($_POST["contact"]);
?>
</body>
</html>
