<html>
<title>Add Customer Booking</title>
<?php
function add_customer_booking($fname, $lname, $contact, $email_id, $table_num, $date, $time)
{
    // Create a new MySQLi connection
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');

    // Check for connection errors
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }

    // Check if the customer already exists in the database
    $query = "SELECT * FROM CUSTOMER WHERE Contact = ?";
    if ($stmt = $dbc->prepare($query)) {
        $stmt->bind_param("i", $contact);  // Bind the contact as an integer
        $stmt->execute();
        $stmt->store_result();
        $check = $stmt->num_rows;

        // If the customer doesn't exist, insert them into the database
        if ($check == 0) {
            $insert_query = "INSERT INTO CUSTOMER (Fname, Lname, Contact, Email_Id) VALUES (?, ?, ?, ?)";
            if ($insert_stmt = $dbc->prepare($insert_query)) {
                $insert_stmt->bind_param("ssis", $fname, $lname, $contact, $email_id);  // Bind the customer data
                $insert_stmt->execute();
                $insert_stmt->close();
            }
        }
        $stmt->close();
    }

    // Get the customer ID based on the contact number
    $query = "SELECT Customer_Id FROM CUSTOMER WHERE Contact = ?";
    if ($stmt = $dbc->prepare($query)) {
        $stmt->bind_param("i", $contact);  // Bind the contact as an integer
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($cust_id);
        $stmt->fetch();
        $stmt->close();
    }

    // Insert the booking details
    $booking_query = "INSERT INTO BOOKING (Table_Num, Date, Time, Cust_Id) VALUES (?, ?, ?, ?)";
    if ($stmt = $dbc->prepare($booking_query)) {
        $stmt->bind_param("issi", $table_num, $date, $time, $cust_id);  // Bind the booking details
        $stmt->execute();
        $stmt->close();
    }

    // Provide feedback to the user and redirect
    echo "<script type='text/javascript'>";
    echo "alert('Booking Done!!!');";
    echo "</script>";
    echo "<meta HTTP-EQUIV='REFRESH' content='0; url=user.html'>";
    
    // Close the database connection
    $dbc->close();
}

add_customer_booking(
    $_POST["firstname"],
    $_POST["lastname"],
    $_POST["contact"],
    $_POST["email_id"],
    $_POST["table_number"],
    $_POST["date"],
    $_POST["time"]
);
?>
<body background="1.png">
</body>
</html>
