<html>
<title>Selected Menu Items</title>
<h1 style="text-align:center"> Selected Menu Items </h1><br/><br/>
<style type="text/css">
label{
    float: left;
    width: 120px;
    font-weight: bold;
}
input, textarea{
    width: 200px;
    margin-bottom: 9px;
}
br{
    clear: left;
}
</style>
<script>
function readOnlyCheckBox() {
    return false;
}
</script>
<body background="1.png">
<?php
function select_menu($menu_id, $cust_id, $fname, $lname, $contact, $email_id)
{
    // Establish MySQLi connection
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');

    // Check for connection errors
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }

    if (empty($menu_id)) {
        echo "<script type=\"text/javascript\">" . "\n";
        echo "alert(\"No Items Selected!!!\");" . "\n";
        echo "</script>" . "\n";
        echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=ask_contact_home_delivery.php\">" . "\n";
    } else {
        // Get customer details using prepared statements
        $stmt = $dbc->prepare("SELECT * FROM CUSTOMER WHERE Customer_Id = ?");
        $stmt->bind_param("i", $cust_id);
        $stmt->execute();
        $res = $stmt->get_result();

    // Check if customer exists
    if ($res->num_rows == 0) {
        echo "Customer not found!";
        return;
    }

    // Display customer details
    $customer = $res->fetch_assoc();

	echo "<form name=\"form1\" action=\"pay_bill_dine.php\" method=\"post\" align=\"center\" onsubmit=\"return checkscript()\">" . "\n";
    echo "<table border=\"4\" style=\"text-align:center;\" align=\"center\" width=\"900\">" . "\n";
    foreach ($customer as $field => $value) {
        echo "<tr>\n";
        echo "<td>\n";
        echo $field;
        echo "</td>\n";
        echo "<td>\n";
        echo "<input type=\"text\" name=\"$field\" value=\"$value\" readonly=\"readonly\">";
        echo "</td>\n";
        echo "</tr>\n";
    }
    echo "</table>" . "\n" . "<br/><br/>\n";


      /*  echo "<form action=\"pay_bill_dine.php\" method=\"post\" align=\"center\">" . "\n";
        echo "<table border=\"4\" style=\"text-align:center;\" align=\"center\" width=\"900\">" . "\n";
        
        while ($field = $res->fetch_field()) {
            echo "<tr>\n";
            echo "<td>\n";
            echo $field->name;
            echo "</td>\n";
            echo "<td>\n";
            $a = $res->fetch_assoc()[$field->name];
            echo "<input type=\"text\" name=\"$field->name\" value=\"$a\" readonly=\"readonly\">";
            echo "</td>\n";
            echo "</tr>\n";
        }*/
        echo "<tr>";
        echo "<td>Table Number</td><td>\n";

        // Get available table numbers
        $table_query = "SELECT Table_Number FROM TABLES;";
        $table = $dbc->query($table_query);
        $num_tables = $table->num_rows;

        echo "<select name=\"table_num\" style=\"width: 200px;\">";
        while ($row = $table->fetch_assoc()) {
            echo "<option value=\"{$row['Table_Number']}\">{$row['Table_Number']}</option>";
        }
        echo "</select></td>\n";
        echo "</tr>" . "\n";
        echo "</table>" . "\n" . "<br/><br/>\n";

        // Fetch menu items
        $query = "SELECT * FROM MENU;";
        $menu = $dbc->query($query);
        $num_fields = $menu->field_count;

        echo "<table border=\"4\" style=\"text-align:center;\" align=\"center\" width=\"900\">" . "\n";
        echo "<tr>\n";
        
        // Display the menu table headers
        while ($field_info = $menu->fetch_field()) {
            echo "<td>\n";
            echo $field_info->name;
            echo "</td>\n";
        }
        echo "<td>\n";
        echo "Selected" . "\n";
        echo "</td>\n";
        echo "<td>\n";
        echo "Quantity" . "\n";
        echo "</td>\n";
        echo "</tr>\n";

        // Display selected menu items
        $num_items = count($menu_id);
        foreach ($menu_id as $id) {
            $menu_item_query = $dbc->prepare("SELECT * FROM MENU WHERE Menu_Id = ?");
            $menu_item_query->bind_param("i", $id);
            $menu_item_query->execute();
            $menu_item = $menu_item_query->get_result()->fetch_assoc();

            echo "<tr>\n";
            foreach ($menu_item as $column => $value) {
                echo "<td>\n";
                echo $value . " " . "\n";
                echo "</td>\n";
            }

            echo "<td>\n";
            echo "<input type=\"checkbox\" name=\"menu[]\" value=\"$id\" checked=\"checked\" onClick=\"return readOnlyCheckBox()\"><br/>" . "\n";
            echo "</td>\n";
            echo "<td>\n";
            echo "<input type=\"text\" name=\"quantity[]\" value=\"1\"><br/>" . "\n";
            echo "</td>\n";
            echo "</tr>\n";
        }
        echo "</table>" . "\n" . "<br/>";
        echo "<input type=\"submit\" value=\"Confirm\">" . "\n";
        echo "</form>";
    }

    // Close the database connection
    $stmt->close();
    $dbc->close();
}

select_menu(
    $_POST["menu"],
    $_POST["Customer_Id"],
    $_POST["Fname"],
    $_POST["Lname"],
    $_POST["Contact"],
    $_POST["Email_Id"]
);
?>
</body>
</html>
