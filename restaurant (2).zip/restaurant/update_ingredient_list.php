<html>
<title> Update Ingredient</title>
<h1 style="text-align:center"> Update Ingredient</h1>

<style type="text/css">
    div.div1 {
        text-align:center;
        font-weight: bold;
    }
</style>

<style type="text/css">
    label {
        float: left;
        width: 120px;
        font-weight: bold;
    }
    input, textarea {
        width: 200px;
        margin-bottom: 9px;
    }
    br {
        clear: left;
    }
</style>

<?php
function print_ingredient()
{
    // Create a new mysqli connection
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');
    
    // Check connection
    if ($dbc->connect_error) {
        die("Connection failed: " . $dbc->connect_error);
    }

    // Query to select ingredients
    $query = "SELECT * FROM INGREDIENT";
    $result = $dbc->query($query);

    // Check if there are results
    if ($result->num_rows == 0) {
        echo "<script type=\"text/javascript\">alert(\"No Ingredients Added!!!\");</script>";
        echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=admin.html\">";
        return;
    }

    // Form to display and update ingredients
    echo "<form action=\"update_ingredient.php\" method=\"post\" align=\"center\">";
    echo "<table border=\"4\" style=\"text-align:center;\" align=\"center\" width=\"900\">";
    echo "<tr>";

    // Display table headers
    $fields = $result->fetch_fields();
    foreach ($fields as $field) {
        echo "<td>" . $field->name . "</td>";
    }
    echo "<td>Select To Update</td>";
    echo "</tr>";

    // Display table rows with ingredients data
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        foreach ($row as $key => $value) {
            echo "<td>" . htmlspecialchars($value) . "</td>";
        }
        echo "<td>";
        echo "<input type=\"radio\" name=\"ingredient\" value=\"" . $row['Ingredient_Id'] . "\"><br/>";
        echo "</td>";
        echo "</tr>";
    }

    echo "</table><br/>";
    echo "<input type=\"submit\" value=\"Update Selected Item\">";
    echo "</form>";

    // Close the database connection
    $dbc->close();
}
?>

<body background="1.png">
<?php
print_ingredient();
?>
</body>
</html>
