<html>
<title>Delete Suppliers</title>
<h1 style="text-align:center"> Delete Suppliers</h1>

<style type="text/css">
    div.div1 {
        text-align: center;
        font-weight: bold;
    }
    label {
        float: left;
        width: 120px;
        font-weight: bold;
    }
    input, textarea {
        width: 200px;
        margin-bottom: 9px;
    }
    br {
        clear: left;
    }
</style>

<?php
function print_suppliers() {
    // Establish database connection using mysqli
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');
    
    // Check for connection error
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }

    // Query to fetch all suppliers
    $query = "SELECT * FROM SUPPLIER";
    $result = $dbc->query($query);

    if ($result->num_rows === 0) {
        echo "<script type=\"text/javascript\">" . "\n";
        echo "alert(\"No Suppliers !!!\");" . "\n";
        echo "</script>" . "\n";
        echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=admin.html\">" . "\n";
        return;
    }

    // Create form to display supplier data with checkboxes
    echo "<form action=\"delete_supplier.php\" method=\"post\" align=\"center\">" . "\n";
    echo "<table border=\"4\" style=\"text-align:center;\" align=\"center\" width=\"900\">" . "\n";
    echo "<tr>\n";
    
    // Fetch and display column names dynamically
    $fields = $result->fetch_fields();
    foreach ($fields as $field) {
        echo "<td>" . $field->name . "</td>\n";
    }

    echo "<td>Select To Delete</td>\n";
    echo "</tr>\n";

    // Fetch and display rows with checkboxes
    while ($row = $result->fetch_assoc()) {
        echo "<tr>\n";
        foreach ($row as $column => $value) {
            echo "<td>" . $value . "</td>\n";
        }
        echo "<td>\n";
        echo "<input type=\"checkbox\" name=\"supplier[]\" value=\"" . $row['Contact'] . "\"><br/>\n";
        echo "</td>\n";
        echo "</tr>\n";
    }

    echo "</table>" . "\n" . "<br/>";
    echo "<input type=\"submit\" value=\"Delete Selected Items\">" . "\n";
    echo "</form>" . "\n";

    // Close the database connection
    $dbc->close();
}
?>

<body background="1.png">
<?php
    print_suppliers();
?>
</body>
</html>
