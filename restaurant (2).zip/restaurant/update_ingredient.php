<html>
<title> Update Ingredient </title>
<style type="text/css">
label{
    float: left;
    width: 300px;
    font-weight: bold;
}
input, textarea{
    width: 200px;
    margin-bottom: 9px;
}
br{
    clear: left;
}
</style>
<script type="text/javascript" src="check_form_validate.js"></script>

<h1 style="text-align:center"> Update Ingredient </h1><br/><br/>

<?php
function update_menu($ing_id)
{
    // Establish database connection using MySQLi
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');
    
    // Check if the connection is successful
    if ($dbc->connect_error) {
        die("Connection failed: " . $dbc->connect_error);
    }
    
    // Check if an ingredient ID is provided
    if (!$ing_id) {
        echo "<script type=\"text/javascript\">"."\n";
        echo "alert(\"No Item Selected!!!\");"."\n";
        echo "</script>"."\n";
        echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=admin.html\">";
        return;
    }
    
    // Prepare the SQL query to select the ingredient by ID
    $query = "SELECT * FROM INGREDIENT WHERE Ingredient_Id = ?";
    if ($stmt = $dbc->prepare($query)) {
        // Bind the ingredient ID as a parameter to the query
        $stmt->bind_param("i", $ing_id);
        
        // Execute the query
        $stmt->execute();
        
        // Get the result
        $result = $stmt->get_result();
        
        // Check if an ingredient was found
        if ($result->num_rows > 0) {
            // Start the form
            echo "<form name=\"form1\" action=\"update_ingredient_values.php\" method=\"post\" align=\"center\" onsubmit=\"return checkscript()\">";
            echo "<table style=\"text-align:center;\" align=\"center\" width=\"400\">";
            
            // Fetch the ingredient data
            $row = $result->fetch_assoc();
            foreach ($row as $field => $value) {
                echo "<tr>";
                echo "<td><b>" . htmlspecialchars($field) . "</b></td>";
                if ($field == "Ingredient_Id") {
                    // Make Ingredient_Id read-only
                    echo "<td><input type=\"text\" name=\"$field\" value=\"" . htmlspecialchars($value) . "\" readonly=\"readonly\"></td>";
                } else {
                    // Make other fields editable
                    echo "<td><input type=\"text\" name=\"$field\" value=\"" . htmlspecialchars($value) . "\"></td>";
                }
                echo "</tr>";
            }
            
            // Submit button
            echo "</table><br/>";
            echo "<input type=\"submit\" name=\"submitbutton\" value=\"Update\">";
            echo "</form>";
        } else {
            echo "<script type=\"text/javascript\">"."\n";
            echo "alert(\"Ingredient not found!!!\");"."\n";
            echo "</script>"."\n";
        }
        
        // Close the prepared statement
        $stmt->close();
    } else {
        echo "Error preparing the query: " . $dbc->error;
    }
    
    // Close the database connection
    $dbc->close();
}

// Call the function to update the menu with the selected ingredient ID
update_menu(intval($_POST["ingredient"]));
?>

</body>
</html>
