<html>
<title>Update Table</title>
<style type="text/css">
label {
    float: left;
    width: 300px;
    font-weight: bold;
}
input, textarea {
    width: 200px;
    margin-bottom: 9px;
}
br {
    clear: left;
}
</style>
<script type="text/javascript" src="check_form_validate.js"></script>

<h1 style="text-align:center">Update Table</h1><br/><br/>

<?php
function update_table($table_id)
{
    // Create a connection to the MySQL database using MySQLi
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');

    // Check for connection errors
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }

    // Check if the table_id is empty
    if (empty($table_id)) {
        echo "<script type=\"text/javascript\">" . "\n";
        echo "alert(\"No Table Selected!!!\");" . "\n";
        echo "</script>" . "\n";
        echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=admin.html\">";
        return;
    }

    // Form for updating table details
    echo "<form name=\"form1\" action=\"update_table_values.php\" method=\"post\" align=\"center\" onsubmit=\"return checkscript()\">" . "\n";
    echo "<table style=\"text-align:center;\" align=\"center\" width=\"400\">" . "\n";

    // Prepare the SQL query to fetch the table details
    $query = "SELECT * FROM TABLES WHERE Table_Number=?";
    $stmt = $dbc->prepare($query);
    $stmt->bind_param('i', $table_id);  // 'i' denotes an integer parameter
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Check if table exists
    if ($result->num_rows == 0) {
        echo "<script type=\"text/javascript\">" . "\n";
        echo "alert(\"No Table Found with that ID!\");" . "\n";
        echo "</script>" . "\n";
        return;
    }

    // Fetch the table data
    $row = $result->fetch_assoc();

    // Loop through the fields and display them in the form
    foreach ($row as $field => $value) {
        echo "<tr>" . "\n";
        echo "<td>" . "\n";
        echo "<b>" . $field . "</b>" . "\n";
        echo "</td>" . "\n";
        echo "<td>" . "\n";
        if ($field == 'Table_Number') {
            echo "<input type=\"text\" name=\"$field\" value=\"$value\" readonly=\"readonly\">";
        } else {
            echo "<input type=\"text\" name=\"$field\" value=\"$value\">";
        }
        echo "</td>" . "\n";
        echo "</tr>" . "\n";
    }

    echo "</table>" . "\n" . "<br/>";
    echo "<input type=\"submit\" name=\"submitbutton\" value=\"Update\">" . "\n";
    echo "</form>" . "\n";

    // Close the prepared statement and database connection
    $stmt->close();
    $dbc->close();
}
?>

<body background="1.png">
<?php
update_table($_POST["table"]);
?>
</body>
</html>
