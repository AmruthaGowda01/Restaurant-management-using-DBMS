<html>
<title>Bill</title>
<h1 style="text-align:center">Bill</h1><br/>
<style type="text/css">
label{
    float: left;
    width: 120px;
    font-weight: bold;
}
input, textarea{
    width: 200px;
    margin-bottom: 9px;
}
br{
    clear: left;
}
</style>
<body background="1.png">
<?php
function print_bill($menu_id, $cust_id, $fname, $lname, $contact, $email_id, $quantity, $table_num) {
    // Establishing a connection to the database
    $dbc = mysqli_connect('localhost', 'root', '', 'restaurant'); // Root user with blank password
    if(!$dbc) {
        die('Connection failed: ' . mysqli_connect_error());
    }

    // Query to get customer details
    $query = "SELECT * FROM CUSTOMER WHERE Customer_Id = $cust_id;";
    $res = mysqli_query($dbc, $query);
    if (!$res) {
        die('Query failed: ' . mysqli_error($dbc));
    }

    $num = mysqli_num_fields($res);
    echo "<table border=\"2\" style=\"text-align:center;\" align=\"center\" width=\"500\">"."\n";
    while ($row = mysqli_fetch_assoc($res)) {
        foreach ($row as $field => $value) {
            echo "<tr>\n";
            echo "<td>\n";
            echo $field;
            echo "</td>\n";
            echo "<td>\n";
            echo "$value\n";
            echo "</td>\n";
            echo "</tr>\n";
        }
    }
    echo "</table><br/>\n";

    // Query to get menu items
    $query = "SELECT * FROM MENU;";
    $menu = mysqli_query($dbc, $query);
    if (!$menu) {
        die('Query failed: ' . mysqli_error($dbc));
    }

    $num_fields = mysqli_num_fields($menu);
    echo "<table border=\"2\" style=\"text-align:center;\" align=\"center\" width=\"500\">"."\n";
    echo "<tr>\n";
    echo "<td>\n";
    echo "S.No"."\n";
    echo "</td>\n";
    for ($i = 1; $i <= 2; $i++) {
        echo "<td>\n";
        echo mysqli_fetch_field_direct($menu, $i)->name;
        if ($i == 2)
            echo " ($)";
        echo "</td>\n";
    }
    echo "<td>\n";
    echo "Quantity"."\n";
    echo "</td>\n";
    echo "<td>\n";
    echo "Total ($)"."\n";
    echo "</td>\n";
    echo "</tr>\n";

    // Calculating the total amount and displaying the selected menu items
    $total_amount = 0;
    $num_items = count($menu_id);
    for ($i = 0; $i < $num_items; $i++) {
        $query = "SELECT Name, Price FROM MENU WHERE Menu_Id = $menu_id[$i];";
        $menu_item = mysqli_query($dbc, $query);
        if (!$menu_item) {
            die('Query failed: ' . mysqli_error($dbc));
        }

        $menu_row = mysqli_fetch_assoc($menu_item);
        $q = $quantity[$i];
        $p = $menu_row['Price'];
        $tot = doubleval($p) * doubleval($q);
        $total_amount += $tot;

        echo "<tr>\n";
        echo "<td>\n";
        echo ($i + 1) . "\n";  // S.No
        echo "</td>\n";
        echo "<td>\n";
        echo $menu_row['Name'] . "\n";
        echo "</td>\n";
		echo "<td>\n";
        echo "$p\n";  // Quantity
        echo "</td>\n";
        echo "<td>\n";
        echo "$q\n";  // Quantity
        echo "</td>\n";
        echo "<td>\n";
        echo "$tot\n";  // Total ($)
        echo "</td>\n";
        echo "</tr>\n";
    }

    // Displaying the total amount
    echo "</table>"."\n"."<br/>";
    echo "<table border=\"2\" style=\"text-align:center;\" align=\"center\" width=\"200\">"."\n";
    echo "</tr><td>Total Amount</td><td>$total_amount</td></tr>\n";
    echo "</table>"."\n"."<br/>";

    // Insert into the BILL table
    $items = "'$fname', '$lname', '$cust_id', '$total_amount'";
    $query = "INSERT INTO `BILL`(`Customer_Fname`, `Customer_Lname`, `Customer_Id`, `Total_Amount`) VALUES ($items);";
    $result = mysqli_query($dbc, $query);
    if (!$result) {
        die('Query failed: ' . mysqli_error($dbc));
    }

    // Get the latest order_id
    $query = "SELECT * FROM BILL;";
    $res = mysqli_query($dbc, $query);
    $order_id = mysqli_num_rows($res);

    // Insert into MENU_BILL table
    for ($i = 0; $i < $num_items; $i++) {
        $query = "SELECT Name, Price FROM MENU WHERE Menu_Id = $menu_id[$i];";
        $menu_item = mysqli_query($dbc, $query);
        if (!$menu_item) {
            die('Query failed: ' . mysqli_error($dbc));
        }

        $menu_row = mysqli_fetch_assoc($menu_item);
        $q = $quantity[$i];
        $p = $menu_row['Price'];
        $name = $menu_row['Name'];
        $items = "'$order_id', '$name', '$q', '$p'";
        $query = "INSERT INTO `MENU_BILL`(`Order_Id`, `Name`, `Quantity`, `Price`) VALUES ($items);";
        $result = mysqli_query($dbc, $query);
        if (!$result) {
            die('Query failed: ' . mysqli_error($dbc));
        }
    }

    // Closing the connection
    mysqli_close($dbc);
}

// Call the function with POST data
print_bill(
    $_POST["menu"],
    $_POST["Customer_Id"],
    $_POST["Fname"],
    $_POST["Lname"],
    $_POST["Contact"],
    $_POST["Email_Id"],
    $_POST["quantity"],
    $_POST["table_num"]
);
?>
</body>
</html>
