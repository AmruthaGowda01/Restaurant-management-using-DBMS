<html>
<title>Check Contact</title>
<?php
function check_booking_contact($contact)
{
    // Create MySQLi connection
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');
    
    // Check for connection errors
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }
    
    if ($contact == "") {
        echo "<script type=\"text/javascript\">"."\n";
        echo "alert(\"No Contact Added!!!\");"."\n";
        echo "</script>"."\n";
        echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=user.html\">";
        return;
    }

    // Query to check if the contact exists in the database
    $query = "SELECT Customer_Id FROM CUSTOMER WHERE Contact = ?";
    if ($stmt = $dbc->prepare($query)) {
        // Bind parameters and execute query
        $stmt->bind_param("s", $contact);
        $stmt->execute();
        $stmt->store_result();
        
        if ($stmt->num_rows > 0) {
            // Contact found, get Customer Id
            $stmt->bind_result($cust_id);
            $stmt->fetch();

            // Redirect to menu page with customer ID
            echo "<form id=\"form1\" name=\"form1\" action=\"menu_dine.php\" method=\"post\">";
            echo "<input type=\"hidden\" name=\"cust_id\" value=\"$cust_id\">";
            echo "<input type=\"submit\" name=\"submitbutton\" value=\"Check\">";
            echo "</form>";
            echo "<script type=\"text/javascript\">"."\n";
            echo "document.getElementById(\"form1\").submit();";
            echo "</script>"."\n";
        } else {
            // Contact not found, redirect to add customer page
            echo "<form id=\"form1\" name=\"form1\" action=\"add_customer_dine.php\" method=\"post\">";
            echo "<input type=\"hidden\" name=\"contact\" value=\"$contact\">";
            echo "<input type=\"submit\" name=\"submitbutton\" value=\"Check\">";
            echo "</form>";
            echo "<script type=\"text/javascript\">"."\n";
            echo "document.getElementById(\"form1\").submit();";
            echo "</script>"."\n";
        }

        $stmt->close(); // Close statement
    } else {
        echo "Error in query preparation: " . $dbc->error;
    }

    // Close the connection
    $dbc->close();
}
?>

<body background="1.png">
<?php
check_booking_contact($_POST["contact"]);
?>
</body>
</html>
