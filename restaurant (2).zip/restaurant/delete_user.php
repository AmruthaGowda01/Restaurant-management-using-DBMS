<!DOCTYPE html>
<html>
<head>
    <title>Delete Users</title>
    <h1 style="text-align:center">Delete Users</h1><br/><br/>
    <style type="text/css">
        label {
            float: left;
            width: 120px;
            font-weight: bold;
        }
        input, textarea {
            width: 200px;
            margin-bottom: 9px;
        }
        br {
            clear: left;
        }
    </style>
</head>
<body background="1.png">
    <?php
        function view_users()
        {
            $conn = mysqli_connect('localhost', 'root', '', 'restaurant');
            if (!$conn) {
                die('NOT CONNECTED: ' . mysqli_connect_error());
            }

            $query = "SELECT * FROM USER";
            $result = mysqli_query($conn, $query);
            if (!$result) {
                die('Query Failed: ' . mysqli_error($conn));
            }

            $num_items = mysqli_num_rows($result);
            $num_fields = mysqli_num_fields($result);

            if ($num_items == 0) {
                echo "<script type=\"text/javascript\">alert(\"No Users !!!\");</script>";
                echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=admin.html\">";
                return;
            }

            // Start form for deleting users
            echo "<form action=\"delete_user_list.php\" method=\"post\" align=\"center\">";
            echo "<table border=\"2\" style=\"text-align:center;\" align=\"center\" width=\"700\">";
            echo "<tr>";

            // Fetch and display field names as table headers
            $fieldinfo = mysqli_fetch_fields($result);
            foreach ($fieldinfo as $field) {
                echo "<td>" . $field->name . "</td>";
            }
            echo "<td>Select To Delete</td>";
            echo "</tr>";

            // Fetch and display rows
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                foreach ($row as $value) {
                    echo "<td>" . htmlspecialchars($value) . "</td>";
                }
                $id = $row['User_Id']; // Assuming 'User_Id' is the primary key
                echo "<td><input type=\"checkbox\" name=\"user[]\" value=\"$id\"><br/></td>";
                echo "</tr>";
            }
            echo "</table><br/>";
            echo "<input type=\"submit\" value=\"Delete Users\">";
            echo "</form>";

            // Free the result set and close the connection
            mysqli_free_result($result);
            mysqli_close($conn);
        }

        // Call the function to display users
        view_users();
    ?>
</body>
</html>
