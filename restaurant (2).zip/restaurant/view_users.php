<!DOCTYPE html>
<html>
<head>
    <title>View Users</title>
    <style type="text/css">
        label {
            float: left;
            width: 300px;
            font-weight: bold;
        }
        input, textarea {
            width: 200px;
            margin-bottom: 9px;
        }
        br {
            clear: left;
        }
    </style>
    <script type="text/javascript" src="check_form_validate.js"></script>
</head>
<body background="1.png">
    <h1 style="text-align:center">Users</h1><br/>
    <?php
        function print_users()
        {
            $conn = mysqli_connect('localhost', 'root', '', 'restaurant');
            if (!$conn) {
                die('NOT CONNECTED: ' . mysqli_connect_error());
            }
            
            $query = "SELECT * FROM USER";
            $users = mysqli_query($conn, $query);
            if (!$users) {
                die('Query Failed: ' . mysqli_error($conn));
            }

            $num_items = mysqli_num_rows($users);
            $num_fields = mysqli_num_fields($users);

            if ($num_items == 0) {
                echo "<script type=\"text/javascript\">alert(\"No Users !!!\");</script>";
                echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=admin.html\">";
                return;
            }

            echo "<form name=\"form1\" action=\"update_user.php\" method=\"post\" align=\"center\" onsubmit=\"return checkscript()\">"."\n";
            echo "<table border=\"2\" style=\"text-align:center;\" align=\"center\" width=\"700\">"."\n";
            echo "<tr>"."\n";

            // Print table headers
            while ($fieldinfo = mysqli_fetch_field($users)) {
                echo "<td>" . $fieldinfo->name . "</td>"."\n";
            }
            echo "<td>Select To Update</td>"."\n";
            echo "</tr>"."\n";

            // Print table rows
            while ($row = mysqli_fetch_assoc($users)) {
                echo "<tr>"."\n";
                foreach ($row as $key => $value) {
                    echo "<td>" . htmlspecialchars($value) . "</td>"."\n";
                }
                $id = $row['User_Id']; // Assuming the first column is the user ID
                echo "<td><input type=\"radio\" name=\"user\" value=\"$id\"><br/></td>"."\n";
                echo "</tr>"."\n";
            }

            echo "</table>"."\n"."<br/>"."\n";
            echo "<input type=\"submit\" value=\"Select\">"."\n";
            echo "</form>"."\n";

            // Free result set
            mysqli_free_result($users);
            // Close connection
            mysqli_close($conn);
        }
    ?>
    <?php print_users(); ?>
</body>
</html>
