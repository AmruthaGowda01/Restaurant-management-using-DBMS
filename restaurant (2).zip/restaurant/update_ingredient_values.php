<html>
<title> Update Ingredient </title>

<?php
function update_ingredient_values($ing_id, $name, $quantity, $desc, $supp_name)
{
    // Create a connection to the MySQL database using MySQLi
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');
    
    // Check if the connection is successful
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }
    
    // Sanitize input data to prevent SQL injection
    $name = $dbc->real_escape_string($name);
    $quantity = $dbc->real_escape_string($quantity);
    $desc = $dbc->real_escape_string($desc);
    $supp_name = $dbc->real_escape_string($supp_name);
    
    // Prepare the SQL query with placeholders to prevent SQL injection
    $query = "UPDATE `INGREDIENT` SET `Name` = ?, `Quantity` = ?, `Description` = ?, `Supp_Name` = ? WHERE `Ingredient_Id` = ?";
    
    // Prepare the statement
    if ($stmt = $dbc->prepare($query)) {
        // Bind parameters to the prepared statement
        $stmt->bind_param("ssssi", $name, $quantity, $desc, $supp_name, $ing_id);
        
        // Execute the query
        if ($stmt->execute()) {
            echo "<script type=\"text/javascript\">
                alert(\"Ingredient Updated!!!\");
            </script>";
            echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=admin.html\">";
        } else {
            echo "<script type=\"text/javascript\">
                alert(\"Error updating ingredient: " . $stmt->error . "\");
            </script>";
        }
        
        // Close the statement
        $stmt->close();
    } else {
        echo "<script type=\"text/javascript\">
            alert(\"Error preparing query: " . $dbc->error . "\");
        </script>";
    }
    
    // Close the database connection
    $dbc->close();
}

// Call the function with POST data to update the ingredient
update_ingredient_values(
    intval($_POST["Ingredient_Id"]),
    $_POST["Name"],
    $_POST["Quantity"],
    $_POST["Description"],
    $_POST["Supp_Name"]
);
?>
<body background="1.png">
</body>
</html>
