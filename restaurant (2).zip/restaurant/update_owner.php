<html>
<title>Update Owner</title>
<style type="text/css">
label {
    float: left;
    width: 300px;
    font-weight: bold;
}
input, textarea {
    width: 200px;
    margin-bottom: 9px;
}
br {
    clear: left;
}
</style>
<script type="text/javascript" src="check_form_validate.js"></script>

<h1 style="text-align:center">Update Owner</h1><br/>
<?php
function update_owner() {
    // Create a new MySQLi connection
    $dbc = new mysqli('localhost', 'root', '', 'restaurant');

    // Check for connection errors
    if ($dbc->connect_error) {
        die('Connection failed: ' . $dbc->connect_error);
    }

    // Query to fetch the owner data
    $query = "SELECT * FROM OWNER";
    $result = $dbc->query($query);

    if ($result->num_rows == 0) {
        echo "No owner data found.";
        return;
    }

    // Fetch the owner data (assumes only one record)
    $owner = $result->fetch_assoc();

    // Create the form for updating owner details
    echo "<form name=\"form1\" action=\"update_owner_values.php\" method=\"post\" align=\"center\" onsubmit=\"return checkscript()\">"."\n";
    echo "<table style=\"text-align:center;\" align=\"center\" width=\"400\">"."\n";

    // Iterate over the fields of the owner data
    foreach ($owner as $field => $value) {
        echo "<tr>"."\n";
        echo "<td>"."\n";
        echo "<b>" . ucfirst($field) . "</b>" . "\n";
        echo "</td>"."\n";
        echo "<td>"."\n";
        
        // If the field is the restaurant name, make it readonly
        if ($field == 'Restaurant_Name') {
            echo "<input type=\"text\" name=\"$field\" value=\"$value\" readonly=\"readonly\">";
        } else {
            echo "<input type=\"text\" name=\"$field\" value=\"$value\">";
        }
        echo "</td>"."\n";
        echo "</tr>"."\n";
    }

    echo "</table>"."\n"."<br/>";
    echo "<input type=\"submit\" name=\"submitbutton\" value=\"Update\">"."\n";
    echo "</form>"."\n";

    // Close the result set and database connection
    $result->free();
    $dbc->close();
}

?>
<body background="1.png">
<?php
update_owner();
?>
</body>
</html>
